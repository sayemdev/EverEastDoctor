package doctor.healthmen.com.bd.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;

import doctor.healthmen.com.bd.R;

public class PendingMessageActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pending_message);
    }

    public void Close(View view) {
        finishAffinity();
    }
}