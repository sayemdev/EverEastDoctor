package doctor.healthmen.com.bd.Activity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import com.bumptech.glide.Glide;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.mikhaellopez.circularimageview.CircularImageView;

import doctor.healthmen.com.bd.Fragments.HomeFragment;
import doctor.healthmen.com.bd.Fragments.InboxFragment;
import doctor.healthmen.com.bd.R;
import doctor.healthmen.com.bd.Utils;

import static doctor.healthmen.com.bd.Constants.IS_LOGGED_IN;
import static doctor.healthmen.com.bd.Constants.PHONE;
import static doctor.healthmen.com.bd.Constants.PROFILE_FILES;
import static doctor.healthmen.com.bd.Constants.PROFILE_PREFERENCE;
import static doctor.healthmen.com.bd.Constants.USER_DATA_PREF;
import static doctor.healthmen.com.bd.Constants.USER_ID;
import static doctor.healthmen.com.bd.Constants.USER_NAME;
import static doctor.healthmen.com.bd.Utils.closeDrawer;
import static doctor.healthmen.com.bd.Utils.openDrawer;
import static doctor.healthmen.com.bd.Utils.redirectToActivity;

public class HomeActivity extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener {

    DrawerLayout drawerLayout;
    TextView nameTextView, phoneTextView, editProfileButton;
    ImageView endToggle, closeDrawer;
    CircularImageView profileImageView;
    String userId, userName, userPhone, profile_url;
    SharedPreferences sharedPreferences, profilePreferences;
    RelativeLayout documentButton, historyButton, logoutButton;
    FrameLayout frameLayout;
    HomeFragment homeFragment = new HomeFragment(this);
    BottomNavigationView bottomNavigationView;
    LinearLayout profileLayout;

    private Context mContext;
    private Boolean mAutoAuthenticateResult;
    private String mEncodedAuthInfo;

    /*, skinCareButton, medicineButton, pediatricsButton, gynaecologyButton, psychiatryButton, sexCureButton, nutritionButton*/
    @SuppressLint({"ResourceAsColor", "SetTextI18n"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);


        mContext = this;

        sharedPreferences = getSharedPreferences(USER_DATA_PREF, MODE_PRIVATE);
        profilePreferences = getSharedPreferences(PROFILE_PREFERENCE, MODE_PRIVATE);

        userName = sharedPreferences.getString(USER_NAME, "");
        userPhone = sharedPreferences.getString(PHONE, "");
        userId = sharedPreferences.getString(USER_ID, "");
        profile_url = PROFILE_FILES + userId + ".jpg";

        drawerLayout = findViewById(R.id.drawerLout);
        endToggle = findViewById(R.id.endToggle);
        profileImageView = findViewById(R.id.profileImageView);
        nameTextView = findViewById(R.id.nameTextView);
        phoneTextView = findViewById(R.id.phoneTextView);
        logoutButton = findViewById(R.id.logoutId);
        closeDrawer = findViewById(R.id.closeDrawer);
        historyButton = findViewById(R.id.historyLtId);
        documentButton = findViewById(R.id.documentLtId);
        editProfileButton = findViewById(R.id.editProfile);
        frameLayout = findViewById(R.id.bottom_nav_frame_layout);
        nameTextView.setText(userName);
        phoneTextView.setText("+88" + userPhone);
        profileLayout = findViewById(R.id.profileLt);
        try {
            Glide.with(HomeActivity.this).load(profile_url).placeholder(R.drawable.ic_profile).into(profileImageView);
        } catch (Exception e) {
            e.printStackTrace();
        }
        endToggle.setOnClickListener(v -> {
            openDrawer(drawerLayout);
        });
        closeDrawer.setOnClickListener(v -> closeDrawer(drawerLayout));

        logoutButton.setOnClickListener(v -> Utils.Logout(this));
        historyButton.setOnClickListener(v -> {
//            redirectToActivity(this, HistoryActivity.class);
            closeDrawer(drawerLayout);
        });
        documentButton.setOnClickListener(v -> {
//            redirectToActivity(this, DocumentsListActivity.class);
//            redirectToActivity(this, MakeACallActivity.class);
            closeDrawer(drawerLayout);
        });
        editProfileButton.setOnClickListener(v -> {
//            startActivity(new Intent(this, EditProfileActivity.class));
        });

        bottomNavigationView = findViewById(R.id.bottom_nav);
        bottomNavigationView.setOnNavigationItemSelectedListener(this);
        bottomNavigationView.setSelectedItemId(R.id.homeMenuId);

        profileLayout.setOnClickListener(v -> {
//            startActivity(new Intent(this, ProfileActivity.class));
            closeDrawer(drawerLayout);
        });

        getSupportFragmentManager().beginTransaction().replace(R.id.bottom_nav_frame_layout, homeFragment).commit();

    }

    @Override
    protected void onStart() {
        super.onStart();
        boolean isLoggedIn = getSharedPreferences(USER_DATA_PREF, MODE_PRIVATE).getBoolean(IS_LOGGED_IN, false);
        if (!isLoggedIn) {
            startActivity(new Intent(HomeActivity.this, MainActivity.class));
            finish();
        }

    }

    @Override
    public void onBackPressed() {
        Intent a = new Intent(Intent.ACTION_MAIN);
        a.addCategory(Intent.CATEGORY_HOME);
        a.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(a);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.homeMenuId) {
            getSupportFragmentManager().beginTransaction().replace(R.id.bottom_nav_frame_layout, homeFragment).commit();
        }
        if (item.getItemId() == R.id.inboxMenuId) {
            getSupportFragmentManager().beginTransaction().replace(R.id.bottom_nav_frame_layout, new InboxFragment()).commit();
        }
        if (item.getItemId() == R.id.billingMenuId) {
            getSupportFragmentManager().beginTransaction().replace(R.id.bottom_nav_frame_layout, new InboxFragment()).commit();
        }
        return true;
    }

}