package doctor.healthmen.com.bd.Fragments;

import android.app.Activity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import androidx.appcompat.widget.SwitchCompat;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.tabs.TabLayout;

import doctor.healthmen.com.bd.Adapter.HomePagerAdapter;
import doctor.healthmen.com.bd.R;

public class HomeFragment extends Fragment {

    Activity activity;
    SwitchCompat switchCompat;
    RelativeLayout relativeLayout;
    TabLayout tabLayout;
    ViewPager viewPager;


    public HomeFragment(Activity activity) {
        this.activity = activity;
    }

    public HomeFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        switchCompat = view.findViewById(R.id.statusSwitch);
        relativeLayout = view.findViewById(R.id.trackBackground);
        tabLayout = view.findViewById(R.id.tab_layout);
        viewPager = view.findViewById(R.id.view_pager);
        AppointmentFragment appointmentFragment = new AppointmentFragment(activity);
        EPrescriptionFragment ePrescriptionFragment = new EPrescriptionFragment();
        DrugDirectoryFragment drugDirectoryFragment = new DrugDirectoryFragment();

        HomePagerAdapter homePagerAdapter = new HomePagerAdapter(getFragmentManager());
        homePagerAdapter.addFragment("lklj", appointmentFragment, activity, R.drawable.appointment_doct);
        homePagerAdapter.addFragment("lkj", ePrescriptionFragment, activity, R.drawable.ic_prescription);
        homePagerAdapter.addFragment("lkj", drugDirectoryFragment, activity, R.drawable.ic_search);
        viewPager.setAdapter(homePagerAdapter);

        tabLayout.setupWithViewPager(viewPager);

        tabLayout.getTabAt(0).setIcon(R.drawable.appointment_doct);
        tabLayout.getTabAt(1).setIcon(R.drawable.ic_prescription);
        tabLayout.getTabAt(2).setIcon(R.drawable.ic_search);

        switchCompat.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                relativeLayout.setBackgroundResource(R.drawable.status_background_checked);
            } else {
                relativeLayout.setBackgroundResource(R.drawable.status_background);
            }
        });

        return view;
    }
}