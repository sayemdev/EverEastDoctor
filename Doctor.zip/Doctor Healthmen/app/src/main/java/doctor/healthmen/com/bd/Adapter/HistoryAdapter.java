package doctor.healthmen.com.bd.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.mikhaellopez.circularimageview.CircularImageView;

import java.util.List;

import doctor.healthmen.com.bd.Constants;
import doctor.healthmen.com.bd.Model.HistoryModel;
import doctor.healthmen.com.bd.R;

/**
 * Health Men created by Sayem Hossen Saimon on 12/29/2020 at 1:10 PM.
 * Email: saimonchowdhuryi96@gmail.com.
 * Phone: +8801882046404.
 **/
public class HistoryAdapter extends RecyclerView.Adapter<HistoryAdapter.ViewHolder> {

    List<HistoryModel> historyModelList;
    Context context;

    public HistoryAdapter(List<HistoryModel> historyModelList, Context context) {
        this.historyModelList = historyModelList;
        this.context = context;
    }

    public HistoryAdapter() {
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.history_item, parent, false));
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        HistoryModel historyModel = historyModelList.get(position);
        holder.appointmentTimeTextView.setText(historyModel.getDate() + ", " + historyModel.getTime());
        holder.patientNameTextView.setText("Patient: " + historyModel.getPatientName());
        holder.doctorNameTextView.setText(historyModel.getDoctorName());
        holder.doctorCategoryTextView.setText("Service: " + historyModel.getCategory());
        Glide.with(context).load(Constants.PROFILE_FILES + historyModel.getProfileName()).placeholder(R.drawable.ic_profile).into(holder.dProfileImageView);
        holder.feeTextView.setText("Fee:" + historyModel.getFee() + "tk");

        Log.d("ViewHolder_TAG", "onBindViewHolder: "+historyModel.getCategory()+"========"+historyModel.getFee());

        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent();
            intent.putExtra("appointmentId", historyModel.getAppointmentId());
            intent.putExtra("history", true);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//            ((Activity)context).finish();
//            context.startActivity(intent);
        });

    }

    @Override
    public int getItemCount() {
        return historyModelList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView appointmentTimeTextView, patientNameTextView, doctorNameTextView, doctorCategoryTextView, feeTextView;
        CircularImageView dProfileImageView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            appointmentTimeTextView = itemView.findViewById(R.id.showDate);
            patientNameTextView = itemView.findViewById(R.id.patientNameTv);
            doctorNameTextView = itemView.findViewById(R.id.doctorNameTv);
            doctorCategoryTextView = itemView.findViewById(R.id.doctorCategory);
            feeTextView = itemView.findViewById(R.id.feeTv);
            dProfileImageView = itemView.findViewById(R.id.dProfileImageView);
        }
    }
}
