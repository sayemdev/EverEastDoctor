package doctor.healthmen.com.bd.Fragments;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import doctor.healthmen.com.bd.Adapter.HistoryAdapter;
import doctor.healthmen.com.bd.Model.HistoryModel;
import doctor.healthmen.com.bd.R;

import static android.content.Context.MODE_PRIVATE;
import static doctor.healthmen.com.bd.Constants.BASE_URL;
import static doctor.healthmen.com.bd.Constants.FEE;
import static doctor.healthmen.com.bd.Constants.USER_DATA_PREF;
import static doctor.healthmen.com.bd.Constants.USER_ID;
import static doctor.healthmen.com.bd.Constants.USER_NAME;

public class AppointmentFragment extends Fragment {

    public AppointmentFragment() {
        // Required empty public constructor
    }

    Activity activity;
 public AppointmentFragment(Activity activity) {
       this.activity=activity;
    }

    private static final String TAG = "HistoryActivity";
    RecyclerView recyclerView;
    List<HistoryModel> historyModelList;
    HistoryAdapter historyAdapter;
    SharedPreferences sharedPreferences;
    String userId,name,fee;
    ProgressBar progressBar;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view=inflater.inflate(R.layout.fragment_appointment, container, false);

        sharedPreferences = activity.getSharedPreferences(USER_DATA_PREF, MODE_PRIVATE);
        userId = sharedPreferences.getString(USER_ID, "");
        name=sharedPreferences.getString(USER_NAME,"");
        fee=sharedPreferences.getString(FEE,"");
        Log.d(TAG, "onCreate: "+userId);
        historyModelList = new ArrayList<>();
        recyclerView =view.findViewById(R.id.historyList);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(activity));
        progressBar=view.findViewById(R.id.progressBarId);
        GetAppointmentList();

        return view;
    }

    private void GetAppointmentList() {
        String url = BASE_URL + "appointment_info_list.php?doctor_id=" + userId;
        Volley.newRequestQueue(activity).add(new StringRequest(Request.Method.GET, url,
                response -> {
            progressBar.setVisibility(View.GONE);
                    try {
                        JSONObject jsonObject1 = new JSONObject(response);
                        JSONArray jsonArray = jsonObject1.getJSONArray("appointment_list");
                        historyModelList.clear();
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject jsonObject = jsonArray.getJSONObject(i);
                            HistoryModel historyModel = new HistoryModel();
                            historyModel.setAppointmentId(jsonObject.getString("appointment_id"));
                            historyModel.setDate(jsonObject.getString("date"));
                            historyModel.setTime(jsonObject.getString("time"));
                            historyModel.setPatientName(jsonObject.getString("patient_name"));
                            historyModel.setDoctorName(jsonObject.getString("d_name"));
                            historyModel.setCategory(jsonObject.getString("d_category"));
                            historyModel.setProfileName(jsonObject.getString("d_image"));
                            historyModel.setFee(jsonObject.getString("d_fee"));
                            Log.d("ViewHold_Ac", "onBindViewHolder: "+jsonObject.getString("patient_name")+"========"+jsonObject.getString("d_category"));
                            if (!jsonObject.getString("date").equals("null")) {
                                historyModelList.add(historyModel);
                            }
                        }
                        historyAdapter = new HistoryAdapter(historyModelList, activity);
                        recyclerView.setAdapter(historyAdapter);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                },
                error -> {
                    Toast.makeText(activity, "Please check your internet connection", Toast.LENGTH_SHORT).show();
                }));
    }

}