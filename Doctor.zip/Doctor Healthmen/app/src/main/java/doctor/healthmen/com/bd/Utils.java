package doctor.healthmen.com.bd;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.text.TextUtils;
import android.widget.Toast;

import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import doctor.healthmen.com.bd.Activity.GetPhoneInput;
import doctor.healthmen.com.bd.Activity.HomeActivity;
import doctor.healthmen.com.bd.Activity.LoginActivity;
import doctor.healthmen.com.bd.utils.AuthenticationUtils;
import doctor.healthmen.com.bd.utils.ToastUtils;

import static android.content.Context.MODE_PRIVATE;
import static doctor.healthmen.com.bd.Constants.DEGREE;
import static doctor.healthmen.com.bd.Constants.BASE_URL;
import static doctor.healthmen.com.bd.Constants.BMDCNO;
import static doctor.healthmen.com.bd.Constants.EMAIL;
import static doctor.healthmen.com.bd.Constants.FEE;
import static doctor.healthmen.com.bd.Constants.JOB_EXPERIENCE;
import static doctor.healthmen.com.bd.Constants.IS_LOGGED_IN;
import static doctor.healthmen.com.bd.Constants.PASSWORD;
import static doctor.healthmen.com.bd.Constants.PHONE;
import static doctor.healthmen.com.bd.Constants.PROFILE_PREFERENCE;
import static doctor.healthmen.com.bd.Constants.USER_DATA_PREF;
import static doctor.healthmen.com.bd.Constants.USER_ID;
import static doctor.healthmen.com.bd.Constants.USER_NAME;
import static doctor.healthmen.com.bd.Constants.imageToString;

/**
 * Health Men created by Sayem Hossen Saimon on 12/13/2020 at 7:05 PM.
 * Email: saimonchowdhuryi96@gmail.com.
 * Phone: +8801882046404.
 **/
public class Utils {
    public static void closeDrawer(DrawerLayout drawerLayout) {
        if (drawerLayout.isDrawerOpen(GravityCompat.END)) {
            drawerLayout.closeDrawer(GravityCompat.END);
        } else {
            drawerLayout.closeDrawer(GravityCompat.END);
        }
    }

    public static void redirectToActivity(Activity activity, Class targetClass) {
        Intent intent = new Intent(activity, targetClass);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        activity.startActivity(intent);
    }
    public static void redirectToVerification(Activity activity, String to) {
        Intent intent = new Intent(activity, GetPhoneInput.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.putExtra("to",to);
        activity.startActivity(intent);
    }

    public static void redirectToDoctor(Activity activity, Class targetClass, String category) {
        Intent intent = new Intent(activity, targetClass);
        intent.putExtra("category", category);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        activity.startActivity(intent);
    }

   /* public static void redirectToDoctorFinal(Activity activity, String category) {
        Intent intent = new Intent(activity, FindDoctorActivity.class);
        intent.putExtra("category", category);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        activity.startActivity(intent);
    }*/

    public static void recreate(Activity activity) {
        activity.recreate();
    }

    public static void Logout(Activity activity) {
        activity.getSharedPreferences(USER_DATA_PREF, MODE_PRIVATE).edit().clear().apply();
        activity.getSharedPreferences(PROFILE_PREFERENCE, MODE_PRIVATE).edit().clear().apply();
        activity.startActivity(new Intent(activity, LoginActivity.class));
        activity.finish();
    }

    public static void openDrawer(DrawerLayout drawerLayout) {
        drawerLayout.openDrawer(GravityCompat.END);
    }

    public static void back(Activity activity) {
        activity.finish();
    }

    public static void redirectWithFinish(Activity activity, Class targetClass) {
        Intent intent = new Intent(activity, targetClass);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        activity.startActivity(intent);
        activity.finish();
    }

    public static void Login(String doctorId, String password, String phone, Activity activity) {
        String url = BASE_URL + "login.php?phone="+phone+"&doctor_id="+doctorId+"&password="+password;
        Volley.newRequestQueue(activity).add(new StringRequest(Request.Method.GET, url, response -> {
            if (response.equals("\"Invalid ID or password\"")) {
                Toast.makeText(activity, "ID or password wrong", Toast.LENGTH_SHORT).show();
            } else {
                try {

                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = jsonObject.getJSONArray("info");
                    JSONObject userObject = jsonArray.getJSONObject(0);

                    SharedPreferences.Editor editor = activity.getSharedPreferences(USER_DATA_PREF, MODE_PRIVATE).edit();
                    editor.putString(USER_NAME, userObject.getString(Maps.NAME));
                    editor.putString(USER_ID, userObject.getString(Maps.DOCTOR_ID));
                    editor.putString(DEGREE, userObject.getString(Maps.DEGREE));
                    editor.putString(EMAIL, userObject.getString(Maps.EMAIL));
                    editor.putString(JOB_EXPERIENCE, userObject.getString(Maps.JOB_EXPERIENCE));
                    editor.putString(PHONE, userObject.getString(Maps.PHONE));
                    editor.putString(BMDCNO, userObject.getString(Maps.BMDC));
                    editor.putString(FEE, userObject.getString(Maps.FEE));
                    editor.putBoolean(IS_LOGGED_IN, true);
                    editor.apply();
                    redirectWithFinish(activity, HomeActivity.class);
                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(activity, "ID or password wrong", Toast.LENGTH_SHORT).show();
                }
            }
        }, error -> {
            Toast.makeText(activity, error.getMessage(), Toast.LENGTH_SHORT).show();
        }));

    }


    public static void ChangePassword(String phone, String password, Activity activity, Class targetClass) {
        Volley.newRequestQueue(activity).add(new StringRequest(Request.Method.POST, BASE_URL + "reset_pass.php",
                response -> {
                    if (response.equals("Failed to changing password")) {
                        Toast.makeText(activity, response, Toast.LENGTH_SHORT).show();
                    } else {
                        redirectWithFinish(activity, targetClass);
                    }
                }, error -> {
            Toast.makeText(activity, error.getMessage(), Toast.LENGTH_SHORT).show();
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> map = new HashMap<>();
                map.put("phone", phone);
                map.put("password", password);
                return map;
            }
        });
    }

    public static void UploadProfileImage(Activity activity, String uid, Bitmap bitmap, ProgressDialog progressDialog) {
        String url = BASE_URL + "update_profile_pic.php";
        String imageName = uid + ".jpg";
        Volley.newRequestQueue(activity).add(new StringRequest(Request.Method.POST, url,
                response -> {
                    progressDialog.dismiss();
                    if (response.equals("Profile picture added")) {
                        Toast.makeText(activity, response, Toast.LENGTH_SHORT).show();
                        activity.startActivity(new Intent(activity, HomeActivity.class));
                    } else {
                        Toast.makeText(activity, response + "", Toast.LENGTH_SHORT).show();
                    }
                }, error -> {
            progressDialog.dismiss();
            Toast.makeText(activity, "Please check your internet connection", Toast.LENGTH_SHORT).show();
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> map = new HashMap<>();
                map.put("patient_id", uid);
                map.put("p_profile", imageName);
                map.put("profile_string", imageToString(bitmap));
                return map;
            }
        });

    }

    public static String generateFileName(String userId, String fileType) {
        Random r = new Random();
        final int i1 = r.nextInt(1000000000 - 1000000) + 1000000;
        return userId + System.currentTimeMillis() + i1 + fileType;
    }

    public static String generateAppointmentId(String userId, String doctorId) {
        Random r = new Random();
        final int i1 = r.nextInt(1000000000 - 1000000) + 1000000;
        return userId + System.currentTimeMillis() + i1 + doctorId;
    }

}
