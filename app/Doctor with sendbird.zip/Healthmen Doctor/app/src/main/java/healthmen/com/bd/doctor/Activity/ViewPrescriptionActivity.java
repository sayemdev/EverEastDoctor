package healthmen.com.bd.doctor.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import healthmen.com.bd.doctor.R;

public class ViewPrescriptionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_prescription);
    }
}