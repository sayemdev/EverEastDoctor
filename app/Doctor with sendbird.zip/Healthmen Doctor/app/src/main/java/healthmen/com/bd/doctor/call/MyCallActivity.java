package healthmen.com.bd.doctor.call;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import healthmen.com.bd.doctor.R;

public class MyCallActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_call);
    }
}