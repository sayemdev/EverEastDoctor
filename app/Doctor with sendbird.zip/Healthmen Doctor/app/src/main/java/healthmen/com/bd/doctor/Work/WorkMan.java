package healthmen.com.bd.doctor.Work;

import android.content.Context;
import android.content.Intent;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import org.jetbrains.annotations.NotNull;

import healthmen.com.bd.doctor.Activity.HistoryActivity;
import healthmen.com.bd.doctor.RCVr;

/**
 * Doctor created by Sayem Hossen Saimon on 8/22/2021 at 8:14 PM.
 * Email: saimonchowdhuryi96@gmail.com.
 * Phone: +8801882046404.
 **/
public class WorkMan extends Worker {
    private static final String TAG = "WorkMan";
    Context context;

    public WorkMan(@NonNull @NotNull Context context, @NonNull @NotNull WorkerParameters workerParams) {
        super(context, workerParams);
        this.context = context;
    }

    @NonNull
    @NotNull
    @Override
    public Result doWork() {
        Log.d(TAG, "WorkMan: " + getInputData().getString("hi"));
/*
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(getApplicationContext(), HistoryActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                getApplicationContext().startActivity(intent);
            }
        });
*/
        Intent intent = new Intent(getApplicationContext(), RCVr.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        getApplicationContext().sendBroadcast(intent);

        /*Intent intent = new Intent(getApplicationContext(), HistoryActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        getApplicationContext().startActivity(intent);*/
        return Result.success();
    }
}
