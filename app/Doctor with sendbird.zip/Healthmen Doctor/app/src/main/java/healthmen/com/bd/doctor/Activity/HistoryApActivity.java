package healthmen.com.bd.doctor.Activity;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;

import com.google.android.material.chip.ChipGroup;

import healthmen.com.bd.doctor.R;
import healthmen.com.bd.doctor.databinding.ActivityHistoryApBinding;

public class HistoryApActivity extends AppCompatActivity {
    NavController navController;
    NavHostFragment navHostFragment;
    ActivityHistoryApBinding binding;
    private ChipGroup chipGroup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityHistoryApBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        navHostFragment = (NavHostFragment) getSupportFragmentManager().findFragmentById(R.id.fragmentContainerView);
        navController = navHostFragment.getNavController();

        chipGroup = findViewById(R.id.filterChipGroup);

        chipGroup.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.allId) {
//                getSupportFragmentManager().beginTransaction().replace(R.id.fragmentContainer, new AllHistoryFragment(userId)).commit();
//                Navigation.findNavController(binding.getRoot()).navigate(R.id.appointmentFragment);
            } else if (checkedId == R.id.upcomingId) {
//                getSupportFragmentManager().beginTransaction().replace(R.id.fragmentContainer, new UpcomingFragment(userId)).commit();
//                Navigation.findNavController(binding.getRoot()).navigate(R.id.upcomingApFragment);
            } else if (checkedId == R.id.completedId) {
//                getSupportFragmentManager().beginTransaction().replace(R.id.fragmentContainer, new CompletedFragment(userId)).commit();
//                Navigation.findNavController(binding.getRoot()).navigate(R.id.completedApFragment);
            }
        });

        binding.completedId.setOnClickListener(v -> {
//            Navigation.findNavController(v).navigate(R.id.completedApFragment);
            navController.navigate(R.id.completedApFragment);
        });

        binding.allId.setOnClickListener(v -> {
//            Navigation.findNavController(v).navigate(R.id.appointmentFragment);
            navController.navigate(R.id.allApFragment);
        });

        binding.upcomingId.setOnClickListener(v -> {
//            Navigation.findNavController(v).navigate(R.id.upcomingApFragment);
            navController.navigate(R.id.upcomingApFragment);
        });

    }

    @Override
    public void onBackPressed() {
        finish();
    }
}