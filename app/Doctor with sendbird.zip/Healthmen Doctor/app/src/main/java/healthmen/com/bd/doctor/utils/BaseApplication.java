package healthmen.com.bd.doctor.utils;


import static android.app.Notification.VISIBILITY_PUBLIC;
import static healthmen.com.bd.doctor.AppointmentTimeFormatting.FormatDoctorTime;
import static healthmen.com.bd.doctor.AppointmentTimeFormatting.IsAvailable;
import static healthmen.com.bd.doctor.Constants.BASE_URL;
import static healthmen.com.bd.doctor.Constants.IS_LOGGED_IN;
import static healthmen.com.bd.doctor.Constants.MY_TOKEN;
import static healthmen.com.bd.doctor.Constants.USER_DATA_PREF;
import static healthmen.com.bd.doctor.Constants.USER_ID;

import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;

import androidx.annotation.RequiresApi;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.OnLifecycleEvent;
import androidx.multidex.MultiDexApplication;
import androidx.work.Data;
import androidx.work.OneTimeWorkRequest;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.messaging.FirebaseMessaging;
import com.sendbird.calls.DirectCall;
import com.sendbird.calls.SendBirdCall;
import com.sendbird.calls.handler.DirectCallListener;
import com.sendbird.calls.handler.SendBirdCallListener;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import healthmen.com.bd.doctor.Maps;
import healthmen.com.bd.doctor.R;
import healthmen.com.bd.doctor.Work.AlarmReceiver;
import healthmen.com.bd.doctor.Work.WorkMan;
import healthmen.com.bd.doctor.call.CallService;
import healthmen.com.bd.doctor.express.AppCenter;
import healthmen.com.bd.doctor.express.ExpressManager;

public class BaseApplication extends MultiDexApplication implements LifecycleObserver { // multidex

    public static final String VERSION = "1.4.0";

    public static final String TAG = "SendBirdApplication";

    // Refer to "https://github.com/sendbird/quickstart-calls-android".
    public static final String APP_ID = "A65EB94B-1654-4B3D-B51D-2B60F3311A77";
    public static final String ACCESS_TOKEN = "";
    public static String CHANNEL_1_ID = "DoctorAlert";
    FirebaseAuth firebaseAuth;
    DatabaseReference userDatabase;
    FirebaseUser firebaseUser;

    boolean isLoggedIn = false;

    @RequiresApi(api = Build.VERSION_CODES.O)
    @SuppressLint("LongLogTag")
    @Override
    public void onCreate() {
        super.onCreate();

        FirebaseDatabase.getInstance().setPersistenceEnabled(true);

        try {
            if (IsAvailable(getSharedPreferences(USER_DATA_PREF, MODE_PRIVATE).getString(Maps.AVAILABLE_ON, ""))) {
                Log.d(TAG, "onCreate: Your duty will be started");
                String time = FormatDoctorTime(getSharedPreferences(USER_DATA_PREF, MODE_PRIVATE).getString(Maps.START, ""));
                Calendar calendar = Calendar.getInstance();
                String date = calendar.get(Calendar.DAY_OF_MONTH) + "/" + (calendar.get(Calendar.MONTH) + 1) + "/" + calendar.get(Calendar.YEAR);

                calendar.set(Calendar.YEAR, Calendar.getInstance().get(Calendar.YEAR));
                calendar.set(Calendar.MONTH, Calendar.getInstance().get(Calendar.MONTH));
                calendar.set(Calendar.DAY_OF_MONTH, Calendar.getInstance().get(Calendar.DAY_OF_MONTH));
                calendar.set(Calendar.HOUR_OF_DAY, Integer.parseInt(time.split(":")[0]));
                calendar.set(Calendar.MINUTE, Integer.parseInt(time.split(":")[1]));
                calendar.add(Calendar.MINUTE, -15);
                calendar.set(Calendar.SECOND, 0);

                String alarmKey = date + " " + time;

                Intent intent2 = new Intent(this, AlarmReceiver.class);
                Bundle b = new Bundle();
                b.putString("alarmKey", alarmKey);
                int pendingKey = (int) calendar.getTimeInMillis();
                Log.d(TAG, "onCreate: " + pendingKey);
                intent2.putExtras(b);

                PendingIntent pendingIntent = PendingIntent.getBroadcast(
                        this, pendingKey, intent2, PendingIntent.FLAG_ONE_SHOT);
                AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
                Log.d(TAG, "onCreate: " + calendar.getTime());
                if (calendar.getTime().after(Calendar.getInstance().getTime())) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pendingIntent);
                    } else {
                        alarmManager.setExact(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pendingIntent);
                    }
                }
            } else {
                Log.d(TAG, "onCreate: Today is your holiday");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        Log.i(BaseApplication.TAG, "[BaseApplication] onCreate()");

        initSendBirdCall(PrefUtils.getAppId(getApplicationContext()));

        isLoggedIn = getSharedPreferences(USER_DATA_PREF, MODE_PRIVATE).getBoolean(IS_LOGGED_IN, false);

        CreateNotificationChannel();

        try {
            if (isLoggedIn) {
                DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference().child("Users").child(getSharedPreferences(USER_DATA_PREF, MODE_PRIVATE).getString(USER_ID, ""));
                databaseReference.child("OnlineStatus").setValue("Online");
                FirebaseMessaging.getInstance().getToken().addOnCompleteListener(task -> {
                    if (task.isComplete()) {
                        String token = task.getResult();
                        Log.i("TAG_H", "onCreate: " + token);
                        databaseReference.child(MY_TOKEN).setValue(task.getResult());
                    }
                });

                Volley.newRequestQueue(this).add(new StringRequest(Request.Method.POST, BASE_URL + "d_opened.php", response -> {
                    Log.d(TAG, "onCreate: "+response);
                }, Throwable::printStackTrace) {
                    @Override
                    protected Map<String, String> getParams() {
                        Map<String, String> map = new HashMap<>();
                        map.put("did", getSharedPreferences(USER_DATA_PREF, MODE_PRIVATE).getString(USER_ID, ""));
                        map.put("time", System.currentTimeMillis() + "");
                        return map;
                    }
                });

            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        minDif();

        ExpressManager.getInstance().createEngine(this, AppCenter.appID);

    }

    private void minDif() {
        Calendar calendar = Calendar.getInstance();

        Calendar calendar1 = Calendar.getInstance();
        calendar1.add(Calendar.MINUTE, 1);
        long diff = calendar1.getTimeInMillis() - calendar.getTimeInMillis();
        long diffMinutes = diff / (60 * 1000) % 60;
        Log.d(TAG, "minDif: " + diffMinutes);

        final OneTimeWorkRequest.Builder workRequest = new OneTimeWorkRequest.Builder(WorkMan.class);
        workRequest.setInitialDelay(diffMinutes, TimeUnit.MINUTES);
        Data.Builder data = new Data.Builder();
//        data.put("hi", "Who are you?");
        workRequest.setInputData(data.build());
/*        WorkManager.getInstance(this).enqueueUniqueWork(System.currentTimeMillis() + "",
                ExistingWorkPolicy.KEEP,
                workRequest.build());*/
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    private void CreateNotificationChannel() {
        String channelId = getString(R.string.default_notification_channel_id);
        Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        AudioAttributes attributes = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .build();

        NotificationChannel defaultNotificationChannel = new NotificationChannel("Default",
                "Default Channel",
                NotificationManager.IMPORTANCE_HIGH);
        defaultNotificationChannel.setSound(defaultSoundUri, attributes);
        defaultNotificationChannel.setLockscreenVisibility(VISIBILITY_PUBLIC);
        defaultNotificationChannel.setDescription("Default");
        defaultNotificationChannel.setShowBadge(true);
        defaultNotificationChannel.enableVibration(true);
        defaultNotificationChannel.enableLights(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            defaultNotificationChannel.setAllowBubbles(true);
        }
        NotificationManager manager = getSystemService(NotificationManager.class);

        NotificationChannel channel = new NotificationChannel("Appointment",
                "Appointment Channel",
                NotificationManager.IMPORTANCE_HIGH);
        manager.deleteNotificationChannel(getResources().getString(R.string.fcm_fallback_notification_channel_label));
        channel.setSound(defaultSoundUri, attributes);
        channel.setLockscreenVisibility(VISIBILITY_PUBLIC);
        channel.setDescription("Default");
        channel.setShowBadge(true);
        channel.enableVibration(true);
        channel.enableLights(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            channel.setAllowBubbles(true);
        }

        NotificationChannel channelWP = new NotificationChannel(channelId,
                "Healthmen Patients",
                NotificationManager.IMPORTANCE_HIGH);

        channelWP.setSound(defaultSoundUri, attributes);
        channelWP.setLockscreenVisibility(VISIBILITY_PUBLIC);
        channelWP.setDescription("Default");
        channelWP.setShowBadge(true);
        channelWP.enableVibration(true);
        channelWP.enableLights(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            channelWP.setAllowBubbles(true);
        }


        NotificationChannel channel1 = new NotificationChannel(
                CHANNEL_1_ID,
                "Channel 1",
                NotificationManager.IMPORTANCE_HIGH
        );

        channel1.setSound(Uri.parse("android.resource://" + getApplicationContext().getPackageName() + "/" + R.raw.alert),
                new AudioAttributes.Builder().setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .setLegacyStreamType(AudioManager.STREAM_RING)
                        .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION).build());
        channel1.setLockscreenVisibility(VISIBILITY_PUBLIC);
        channel1.setDescription("This is Channel 1");
        channel1.setShowBadge(true);
        channel1.enableVibration(true);
        channel1.enableLights(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            channel1.setAllowBubbles(true);
        }
        channel1.setImportance(NotificationManager.IMPORTANCE_HIGH);

        manager.createNotificationChannel(channel1);

        manager.createNotificationChannel(channelWP);

        manager.createNotificationChannel(channel);
        manager.createNotificationChannel(defaultNotificationChannel);

    }

    @SuppressLint("LongLogTag")
    public boolean initSendBirdCall(String appId) {
        Log.i(BaseApplication.TAG, "[BaseApplication] initSendBirdCall(appId: " + appId + ")");
        Context context = getApplicationContext();

        if (TextUtils.isEmpty(appId)) {
            appId = APP_ID;
        }

        if (SendBirdCall.init(context, appId)) {
            SendBirdCall.removeAllListeners();
            SendBirdCall.addListener(UUID.randomUUID().toString(), new SendBirdCallListener() {
                @Override
                public void onRinging(DirectCall call) {
                    int ongoingCallCount = SendBirdCall.getOngoingCallCount();
                    Log.i(BaseApplication.TAG, "[BaseApplication] onRinging() => callId: " + call.getCallId() + ", getOngoingCallCount(): " + ongoingCallCount);

                    if (ongoingCallCount >= 2) {
                        call.end();
                        return;
                    }

/*
                    Intent intent = new Intent(context, MyCallActivity.class);
                    intent.putExtra("EXTRA_INCOMING_CALL_ID", call.getCallId());
                    getApplicationContext().startActivity(intent);
*/

                    call.setListener(new DirectCallListener() {
                        @Override
                        public void onConnected(DirectCall call) {
                        }

                        @SuppressLint("LongLogTag")
                        @Override
                        public void onEnded(DirectCall call) {
                            int ongoingCallCount = SendBirdCall.getOngoingCallCount();
                            Log.i(BaseApplication.TAG, "[BaseApplication] onEnded() => callId: " + call.getCallId() + ", getOngoingCallCount(): " + ongoingCallCount);

                            BroadcastUtils.sendCallLogBroadcast(context, call.getCallLog());

                            if (ongoingCallCount == 0) {
                                CallService.stopService(context);
                            }
                        }
                    });

                    CallService.onRinging(context, call);
                }
            });

            SendBirdCall.Options.addDirectCallSound(SendBirdCall.SoundType.DIALING, R.raw.dialing);
            SendBirdCall.Options.addDirectCallSound(SendBirdCall.SoundType.RINGING, R.raw.ringing);
            SendBirdCall.Options.addDirectCallSound(SendBirdCall.SoundType.RECONNECTING, R.raw.reconnecting);
            SendBirdCall.Options.addDirectCallSound(SendBirdCall.SoundType.RECONNECTED, R.raw.reconnected);
            return true;
        }
        return false;
    }


    @OnLifecycleEvent(Lifecycle.Event.ON_STOP)
    private void onAppBackgrounded() {
        Log.d("MyApp", "App in background");
        if (isLoggedIn) {
            DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference().child("Users").child(getSharedPreferences(USER_DATA_PREF, MODE_PRIVATE).getString(USER_ID, " "));
            databaseReference.child("OnlineStatus").setValue("Offline");
        }
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_START)
    private void onAppForegrounded() {
        Log.d("MyApp", "App in foreground");
        if (isLoggedIn) {
            DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference().child("Users").child(getSharedPreferences(USER_DATA_PREF, MODE_PRIVATE).getString(USER_ID, " "));
            databaseReference.child("OnlineStatus").setValue("Online");
        }
    }

}
