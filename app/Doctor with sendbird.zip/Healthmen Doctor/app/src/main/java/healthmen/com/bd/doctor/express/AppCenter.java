package healthmen.com.bd.doctor.express;

public class AppCenter {

    // Get your AppID from ZEGOCLOUD Console
    //[My Projects] : https://console.zegocloud.com/project
    public static long appID = 1409243965;

    // Get your ServerSecret from ZEGOCLOUD Console
    // [My Projects -> project's Edit -> Server Secret Keys] : https://console.zegocloud.com/project"
    public static String serverSecret = "d6bb2150b5309e1e2ddfb7c6f967eb3d";

}
