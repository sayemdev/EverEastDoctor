package healthmen.com.bd.doctor.express;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.CountDownTimer;
import android.os.IBinder;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.TextureView;
import android.view.View;
import android.view.WindowManager;

import androidx.annotation.Nullable;

import healthmen.com.bd.doctor.R;
import healthmen.com.bd.doctor.login.VideoCallActivity;
import im.zego.zegoexpress.ZegoExpressEngine;
import im.zego.zegoexpress.constants.ZegoViewMode;
import im.zego.zegoexpress.entity.ZegoCanvas;

public class FloatingWindowService extends Service {
    private static final String TAG = "FloatingWindowService";
    WindowManager windowManager;
    LayoutInflater layoutInflater;
    private WindowManager.LayoutParams layoutParams;
    private View display;
    private TextureView textureView;

    @Override
    public void onCreate() {
        super.onCreate();
        layoutInflater = LayoutInflater.from(FloatingWindowService.this);
        display = layoutInflater.inflate(R.layout.floating_layout, null);
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        DisplayMetrics dm = new DisplayMetrics();
        windowManager.getDefaultDisplay().getMetrics(dm);
        layoutParams = new WindowManager.LayoutParams();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            layoutParams = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                    PixelFormat.TRANSLUCENT);
        } else {
            layoutParams = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_PHONE,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                    PixelFormat.TRANSLUCENT);
        }

      /*  // Set the image format, the effect is transparent background.
        layoutParams.format = PixelFormat.RGB_565;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            // android 8.0 and later
            layoutParams.type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else {
            //before android 8.0
            layoutParams.type = WindowManager.LayoutParams.TYPE_PHONE;
        }
        //The flags describe the mode of the window, whether it can be touched, can be
        // focused, etc.
        layoutParams.flags = 0;*/
        // Set the video playback window size
        layoutParams.width = dm.widthPixels / 3;
        layoutParams.height = dm.heightPixels / 3;
        layoutParams.x = 700;
        layoutParams.y = 0;

    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        super.onStartCommand(intent, flags, startId);
        //Get current streamId
        String streamId = intent.getStringExtra("streamId");
        Log.d(TAG, "onStartCommand: " + streamId);
        //Judge whether there is a floating window permission
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (Settings.canDrawOverlays(FloatingWindowService.this)) {
                display = layoutInflater.inflate(R.layout.floating_layout, null);
                textureView = display.findViewById(R.id.layout_little_video_window);
                ZegoCanvas canvas = generateCanvas(textureView);

                if (ZegoExpressEngine.getEngine() != null) {
                    ZegoExpressEngine.getEngine().startPlayingStream(ExpressManager.getInstance().generateStreamID(getSharedPreferences("CALL", MODE_PRIVATE).getString("participant", ""),
                            getSharedPreferences("CALL", MODE_PRIVATE).getString("roomId", "")), canvas);
                }

                textureView.setOnClickListener(v -> {
                    startActivity(new Intent(FloatingWindowService.this, VideoCallActivity.class).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                });

                //Add layout to current window!!!
                windowManager.addView(display, layoutParams);
                textureView.setOnTouchListener(new View.OnTouchListener() {
                    private int initialX;
                    private int initialY;
                    private float initialTouchX;
                    private float initialTouchY;

                    @Override
                    public boolean onTouch(View v, MotionEvent event) {
                        Log.d("AD", "Action E" + event);
                        switch (event.getAction()) {
                            case MotionEvent.ACTION_DOWN:
                                Log.d("AD", "Action Down");
                                initialX = layoutParams.x;
                                initialY = layoutParams.y;
                                initialTouchX = event.getRawX();
                                initialTouchY = event.getRawY();
                                return false;
                            case MotionEvent.ACTION_UP:
                                Log.d("AD", "Action Up");
                                int Xdiff = (int) (event.getRawX() - initialTouchX);
                                int Ydiff = (int) (event.getRawY() - initialTouchY);
                                return false;
                            case MotionEvent.ACTION_MOVE:
                                Log.d("AD", "Action Move");
                                layoutParams.x = initialX + (int) (event.getRawX() - initialTouchX);
                                layoutParams.y = initialY + (int) (event.getRawY() - initialTouchY);
                                windowManager.updateViewLayout(display, layoutParams);
                                return false;
                        }
                        return false;
                    }
                });
            }
        }

        return START_STICKY;
    }
    private CountDownTimer countDownTimer;
    @Override
    public void onDestroy() {
        super.onDestroy();
        if (windowManager != null)
            windowManager.removeViewImmediate(display);
    }

    private ZegoCanvas generateCanvas(TextureView textureView) {
        ZegoCanvas canvas = new ZegoCanvas(textureView);
        canvas.viewMode = ZegoViewMode.ASPECT_FILL;
        return canvas;
    }
}