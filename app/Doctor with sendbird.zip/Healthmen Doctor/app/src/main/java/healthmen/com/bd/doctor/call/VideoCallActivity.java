package healthmen.com.bd.doctor.call;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.PictureInPictureParams;
import android.content.res.Configuration;
import android.os.Build;
import android.util.Log;
import android.util.Rational;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import com.sendbird.calls.AcceptParams;
import com.sendbird.calls.AudioDevice;
import com.sendbird.calls.CallOptions;
import com.sendbird.calls.DialParams;
import com.sendbird.calls.DirectCall;
import com.sendbird.calls.DirectCallUserRole;
import com.sendbird.calls.SendBirdCall;
import com.sendbird.calls.SendBirdVideoView;

import org.webrtc.RendererCommon;

import java.util.Set;

import healthmen.com.bd.doctor.R;
import healthmen.com.bd.doctor.utils.BaseApplication;
import healthmen.com.bd.doctor.utils.ToastUtils;

public class VideoCallActivity extends CallActivity {

    ImageView minimize;
    /*
        @Override
        public void onUserLeaveHint () {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    PictureInPictureParams pictureInPictureParams=new PictureInPictureParams.Builder().build();
                    enterPictureInPictureMode(pictureInPictureParams);
                }

            }
        }
    */
    LinearLayout linear_layout_info, linear_layout_connecting_buttons;
    RelativeLayout relative_layout_ringing_buttons;
    STATE state;
    boolean isInPictureInPictureMode;
    private boolean mIsVideoEnabled;
    //+ Views
    private SendBirdVideoView mVideoViewFullScreen;
    private View mViewConnectingVideoViewFullScreenFg;
    private RelativeLayout mRelativeLayoutVideoViewSmall;
    private SendBirdVideoView mVideoViewSmall;
    private ImageView mImageViewCameraSwitch;
    //- Views
    private ImageView mImageViewVideoOff, image_view_profile;

    @Override
    public void onPictureInPictureModeChanged(boolean isInPictureInPictureMode, Configuration newConfig) {
        this.isInPictureInPictureMode = isInPictureInPictureMode;
        if (isInPictureInPictureMode) {
            // Hide the full-screen UI (controls, etc.) while in picture-in-picture mode.
            mVideoViewSmall.setVisibility(View.GONE);
            image_view_profile.setVisibility(View.GONE);
            mImageViewCameraSwitch.setVisibility(View.GONE);
            linear_layout_info.setVisibility(View.GONE);
            linear_layout_connecting_buttons.setVisibility(View.GONE);
            relative_layout_ringing_buttons.setVisibility(View.GONE);
        } else {
            // Restore the full-screen UI.
            mVideoViewSmall.setVisibility(View.VISIBLE);
            image_view_profile.setVisibility(View.VISIBLE);
            mImageViewCameraSwitch.setVisibility(View.VISIBLE);
            linear_layout_info.setVisibility(View.VISIBLE);
            linear_layout_connecting_buttons.setVisibility(View.VISIBLE);
            minimize.setVisibility(View.VISIBLE);
            if (state != null) {
                switch (state) {
                    case STATE_ACCEPTING: {
                        mVideoViewFullScreen.setVisibility(View.GONE);
                        mViewConnectingVideoViewFullScreenFg.setVisibility(View.GONE);
                        mRelativeLayoutVideoViewSmall.setVisibility(View.GONE);
                        mImageViewCameraSwitch.setVisibility(View.GONE);
                        break;
                    }

                    case STATE_OUTGOING: {
                        mVideoViewFullScreen.setVisibility(View.VISIBLE);
                        mViewConnectingVideoViewFullScreenFg.setVisibility(View.VISIBLE);
                        mRelativeLayoutVideoViewSmall.setVisibility(View.GONE);
                        mImageViewCameraSwitch.setVisibility(View.VISIBLE);
                        mImageViewVideoOff.setVisibility(View.VISIBLE);
                        break;
                    }

                    case STATE_CONNECTED: {
                        mVideoViewFullScreen.setVisibility(View.VISIBLE);
                        mViewConnectingVideoViewFullScreenFg.setVisibility(View.GONE);
                        mRelativeLayoutVideoViewSmall.setVisibility(View.VISIBLE);
                        mImageViewCameraSwitch.setVisibility(View.VISIBLE);
                        mImageViewVideoOff.setVisibility(View.VISIBLE);

                        mLinearLayoutInfo.setVisibility(View.GONE);

                        if (mDirectCall != null && mDirectCall.getMyRole() == DirectCallUserRole.CALLER) {
                            mDirectCall.setLocalVideoView(mVideoViewSmall);
                            mDirectCall.setRemoteVideoView(mVideoViewFullScreen);
                        }
                        break;
                    }

                    case STATE_ENDING:
                    case STATE_ENDED: {
                        mLinearLayoutInfo.setVisibility(View.VISIBLE);

                        mVideoViewFullScreen.setVisibility(View.GONE);
                        mViewConnectingVideoViewFullScreenFg.setVisibility(View.GONE);
                        mRelativeLayoutVideoViewSmall.setVisibility(View.GONE);
                        mImageViewCameraSwitch.setVisibility(View.GONE);
                    }
                    break;
                }

            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mDirectCall != null && !mDirectCall.isLocalVideoEnabled()) {
            mDoLocalVideoStart = true;
            mDirectCall.startVideo();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                PictureInPictureParams pictureInPictureParams = new PictureInPictureParams.Builder().setAspectRatio(new Rational(2, 3)).build();
                enterPictureInPictureMode(pictureInPictureParams);
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                PictureInPictureParams pictureInPictureParams = new PictureInPictureParams.Builder().setAspectRatio(new Rational(2, 3)).build();
                enterPictureInPictureMode(pictureInPictureParams);
            }
        }
    }

    @Override
    protected int getLayoutResourceId() {
        return R.layout.activity_video_call;
    }

    @Override
    protected void initViews() {
        super.initViews();
        Log.i(BaseApplication.TAG, "[VideoCallActivity] initViews()");

        mVideoViewFullScreen = findViewById(R.id.video_view_fullscreen);
        mViewConnectingVideoViewFullScreenFg = findViewById(R.id.view_connecting_video_view_fullscreen_fg);
        mRelativeLayoutVideoViewSmall = findViewById(R.id.relative_layout_video_view_small);
        mVideoViewSmall = findViewById(R.id.video_view_small);
        mImageViewCameraSwitch = findViewById(R.id.image_view_camera_switch);
        mImageViewVideoOff = findViewById(R.id.image_view_video_off);
        image_view_profile = findViewById(R.id.image_view_profile);
        linear_layout_info = findViewById(R.id.linear_layout_info);
        linear_layout_connecting_buttons = findViewById(R.id.linear_layout_connecting_buttons);
        relative_layout_ringing_buttons = findViewById(R.id.relative_layout_ringing_buttons);
        minimize = findViewById(R.id.minimize2);

    }

    @Override
    protected void setViews() {
        super.setViews();

        mVideoViewFullScreen.setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FIT);
        mVideoViewFullScreen.setZOrderMediaOverlay(false);
        mVideoViewFullScreen.setEnableHardwareScaler(true);

        mVideoViewSmall.setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FIT);
        mVideoViewSmall.setZOrderMediaOverlay(true);
        mVideoViewSmall.setEnableHardwareScaler(true);

        if (mDirectCall != null) {
            if (mDirectCall.getMyRole() == DirectCallUserRole.CALLER && mState == STATE.STATE_OUTGOING) {
                mDirectCall.setLocalVideoView(mVideoViewFullScreen);
                mDirectCall.setRemoteVideoView(mVideoViewSmall);
            } else {
                mDirectCall.setLocalVideoView(mVideoViewSmall);
                mDirectCall.setRemoteVideoView(mVideoViewFullScreen);
            }
        }

        mImageViewCameraSwitch.setOnClickListener(view -> {
            if (mDirectCall != null) {
                mDirectCall.switchCamera(e -> {
                    if (e != null) {
                        Log.i(BaseApplication.TAG, "[VideoCallActivity] switchCamera(e: " + e.getMessage() + ")");
                    }
                });
            }
        });

        if (mDirectCall != null && !mDoLocalVideoStart) {
            mIsVideoEnabled = mDirectCall.isLocalVideoEnabled();
        } else {
            mIsVideoEnabled = true;
        }
        mImageViewVideoOff.setSelected(!mIsVideoEnabled);
        mImageViewVideoOff.setOnClickListener(view -> {
            if (mDirectCall != null) {
                if (mIsVideoEnabled) {
                    Log.i(BaseApplication.TAG, "[VideoCallActivity] stopVideo()");
                    mDirectCall.stopVideo();
                    mIsVideoEnabled = false;
                    mImageViewVideoOff.setSelected(true);
                } else {
                    Log.i(BaseApplication.TAG, "[VideoCallActivity] startVideo()");
                    mDirectCall.startVideo();
                    mIsVideoEnabled = true;
                    mImageViewVideoOff.setSelected(false);
                }
            }
        });

        minimize.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    PictureInPictureParams pictureInPictureParams = new PictureInPictureParams.Builder().setAspectRatio(new Rational(2, 3)).build();
                    enterPictureInPictureMode(pictureInPictureParams);
                }

            }
        });

        mImageViewBluetooth.setEnabled(false);
        mImageViewBluetooth.setOnClickListener(view -> {
            mImageViewBluetooth.setSelected(!mImageViewBluetooth.isSelected());
            if (mDirectCall != null) {
                if (mImageViewBluetooth.isSelected()) {
                    mDirectCall.selectAudioDevice(AudioDevice.BLUETOOTH, e -> {
                        if (e != null) {
                            mImageViewBluetooth.setSelected(false);
                        }
                    });
                } else {
                    mDirectCall.selectAudioDevice(AudioDevice.WIRED_HEADSET, e -> {
                        if (e != null) {
                            mDirectCall.selectAudioDevice(AudioDevice.SPEAKERPHONE, null);
                        }
                    });
                }
            }
        });
    }

    protected void setLocalVideoSettings(DirectCall call) {
        mIsVideoEnabled = call.isLocalVideoEnabled();
        Log.i(BaseApplication.TAG, "[VideoCallActivity] setLocalVideoSettings() => isLocalVideoEnabled(): " + mIsVideoEnabled);
        mImageViewVideoOff.setSelected(!mIsVideoEnabled);
    }

    @Override
    protected void setAudioDevice(AudioDevice currentAudioDevice, Set<AudioDevice> availableAudioDevices) {
        if (currentAudioDevice == AudioDevice.SPEAKERPHONE) {
            mImageViewBluetooth.setSelected(false);
        } else if (currentAudioDevice == AudioDevice.BLUETOOTH) {
            mImageViewBluetooth.setSelected(true);
        }

        if (availableAudioDevices.contains(AudioDevice.BLUETOOTH)) {
            mImageViewBluetooth.setEnabled(true);
        } else if (!mImageViewBluetooth.isSelected()) {
            mImageViewBluetooth.setEnabled(false);
        }
    }

    @Override
    protected void startCall(boolean amICallee) {
        CallOptions callOptions = new CallOptions();
        callOptions.setVideoEnabled(mIsVideoEnabled).setAudioEnabled(mIsAudioEnabled);

        if (amICallee) {
            callOptions.setLocalVideoView(mVideoViewSmall).setRemoteVideoView(mVideoViewFullScreen);
        } else {
            callOptions.setLocalVideoView(mVideoViewFullScreen).setRemoteVideoView(mVideoViewSmall);
        }

        if (amICallee) {
            Log.i(BaseApplication.TAG, "[VideoCallActivity] accept()");
            if (mDirectCall != null) {
                mDirectCall.accept(new AcceptParams().setCallOptions(callOptions));
            }
        } else {
            Log.i(BaseApplication.TAG, "[VideoCallActivity] dial()");
            mDirectCall = SendBirdCall.dial(new DialParams(mCalleeIdToDial).setVideoCall(mIsVideoCall).setCallOptions(callOptions), (call, e) -> {
                if (e != null) {
                    Log.i(BaseApplication.TAG, "[VideoCallActivity] dial() => e: " + e.getMessage());
                    if (e.getMessage() != null) {
                        ToastUtils.showToast(mContext, e.getMessage());
                    }

                    finishWithEnding(e.getMessage());
                    return;
                }

                Log.i(BaseApplication.TAG, "[VideoCallActivity] dial() => OK");
                updateCallService();
            });
            setListener(mDirectCall);
        }
    }

    @SuppressLint("SourceLockedOrientationActivity")
    @TargetApi(18)
    @Override
    protected boolean setState(STATE state, DirectCall call) {
        if (!super.setState(state, call)) {
            return false;
        }
        this.state = state;
        if (!isInPictureInPictureMode) {
            switch (state) {
                case STATE_ACCEPTING: {
                    mVideoViewFullScreen.setVisibility(View.GONE);
                    mViewConnectingVideoViewFullScreenFg.setVisibility(View.GONE);
                    mRelativeLayoutVideoViewSmall.setVisibility(View.GONE);
                    mImageViewCameraSwitch.setVisibility(View.GONE);
                    break;
                }

                case STATE_OUTGOING: {
                    mVideoViewFullScreen.setVisibility(View.VISIBLE);
                    mViewConnectingVideoViewFullScreenFg.setVisibility(View.VISIBLE);
                    mRelativeLayoutVideoViewSmall.setVisibility(View.GONE);
                    mImageViewCameraSwitch.setVisibility(View.VISIBLE);
                    mImageViewVideoOff.setVisibility(View.VISIBLE);
                    break;
                }

                case STATE_CONNECTED: {
                    mVideoViewFullScreen.setVisibility(View.VISIBLE);
                    mViewConnectingVideoViewFullScreenFg.setVisibility(View.GONE);
                    mRelativeLayoutVideoViewSmall.setVisibility(View.VISIBLE);
                    mImageViewCameraSwitch.setVisibility(View.VISIBLE);
                    mImageViewVideoOff.setVisibility(View.VISIBLE);

                    mLinearLayoutInfo.setVisibility(View.GONE);

                    if (call != null && call.getMyRole() == DirectCallUserRole.CALLER) {
                        call.setLocalVideoView(mVideoViewSmall);
                        call.setRemoteVideoView(mVideoViewFullScreen);
                    }
                    break;
                }

                case STATE_ENDING:
                case STATE_ENDED: {
                    mLinearLayoutInfo.setVisibility(View.VISIBLE);
                    mVideoViewFullScreen.setVisibility(View.GONE);
                    mViewConnectingVideoViewFullScreenFg.setVisibility(View.GONE);
                    mRelativeLayoutVideoViewSmall.setVisibility(View.GONE);
                    mImageViewCameraSwitch.setVisibility(View.GONE);
                }
                break;
            }
            return true;
        } else if (isInPictureInPictureMode) {
            switch (state) {
                case STATE_ACCEPTING: {
                    mVideoViewFullScreen.setVisibility(View.GONE);
                    mViewConnectingVideoViewFullScreenFg.setVisibility(View.GONE);
                    mRelativeLayoutVideoViewSmall.setVisibility(View.GONE);
                    mImageViewCameraSwitch.setVisibility(View.GONE);
                    break;
                }

                case STATE_OUTGOING: {
                    mVideoViewFullScreen.setVisibility(View.VISIBLE);
                    mRelativeLayoutVideoViewSmall.setVisibility(View.GONE);
                    mViewConnectingVideoViewFullScreenFg.setVisibility(View.VISIBLE);
                    mRelativeLayoutVideoViewSmall.setVisibility(View.GONE);
                    mImageViewCameraSwitch.setVisibility(View.VISIBLE);
                    mImageViewVideoOff.setVisibility(View.VISIBLE);
                    break;
                }

                case STATE_CONNECTED: {
                    mVideoViewFullScreen.setVisibility(View.VISIBLE);
                    mRelativeLayoutVideoViewSmall.setVisibility(View.GONE);
                    mViewConnectingVideoViewFullScreenFg.setVisibility(View.GONE);
                    mImageViewCameraSwitch.setVisibility(View.GONE);
                    mImageViewVideoOff.setVisibility(View.GONE);
                    mVideoViewSmall.setVisibility(View.GONE);
                    image_view_profile.setVisibility(View.GONE);
                    mImageViewCameraSwitch.setVisibility(View.GONE);
                    linear_layout_info.setVisibility(View.GONE);
                    linear_layout_connecting_buttons.setVisibility(View.GONE);
                    relative_layout_ringing_buttons.setVisibility(View.GONE);
                    mLinearLayoutInfo.setVisibility(View.GONE);

                    if (call != null && call.getMyRole() == DirectCallUserRole.CALLER) {
                        call.setLocalVideoView(mVideoViewSmall);
                        call.setRemoteVideoView(mVideoViewFullScreen);
                    }
                    break;
                }

                case STATE_ENDED: {
                    /*     mLinearLayoutInfo.setVisibility(View.VISIBLE);*/

                    mVideoViewFullScreen.setVisibility(View.GONE);
                    mViewConnectingVideoViewFullScreenFg.setVisibility(View.GONE);
                    mRelativeLayoutVideoViewSmall.setVisibility(View.GONE);
                    mImageViewCameraSwitch.setVisibility(View.GONE);
                }
                break;
            }
            return true;
        } else {
            return false;
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.i(BaseApplication.TAG, "[VideoCallActivity] onStart()");
        if (mDirectCall != null && mDoLocalVideoStart) {
            mDoLocalVideoStart = false;
            updateCallService();
            mDirectCall.startVideo();
        }
    }

   /* @Override
    protected void onStop() {
        super.onStop();
        Log.i(BaseApplication.TAG, "[VideoCallActivity] onStop()");

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                PictureInPictureParams pictureInPictureParams = new PictureInPictureParams.Builder().setAspectRatio(new Rational(2, 3)).build();
                enterPictureInPictureMode(pictureInPictureParams);
            }
        }
    }*/
}
