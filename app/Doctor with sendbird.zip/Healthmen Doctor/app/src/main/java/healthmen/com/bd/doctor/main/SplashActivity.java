package healthmen.com.bd.doctor.main;

import static healthmen.com.bd.doctor.Constants.MAIN_URL;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.play.core.appupdate.AppUpdateInfo;
import com.google.android.play.core.appupdate.AppUpdateManager;
import com.google.android.play.core.appupdate.AppUpdateManagerFactory;
import com.google.android.play.core.install.model.AppUpdateType;
import com.google.android.play.core.install.model.UpdateAvailability;
import com.google.android.play.core.tasks.Task;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import healthmen.com.bd.doctor.DrugDB.CartDatabaseClient;
import healthmen.com.bd.doctor.DrugDB.MedicinesModel;
import healthmen.com.bd.doctor.R;
import healthmen.com.bd.doctor.databinding.ActivitySplashBinding;
import healthmen.com.bd.doctor.utils.ActivityUtils;
import healthmen.com.bd.doctor.utils.AuthenticationUtils;
import healthmen.com.bd.doctor.utils.BaseApplication;
import healthmen.com.bd.doctor.utils.ToastUtils;

public class SplashActivity extends AppCompatActivity {
    private static final int SPLASH_TIME_MS = 1000;
    private static final int IMMEDIATE_APP_UPDATE_REQ_CODE = 124;
    private static final String TAG = "SplashActivity";
    ActivitySplashBinding binding;
    private Context mContext;
    private Timer mTimer;
    private Boolean mAutoAuthenticateResult;
    private String mEncodedAuthInfo;
    private AppUpdateManager appUpdateManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySplashBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        mContext = this;

        appUpdateManager = AppUpdateManagerFactory.create(getApplicationContext());
        checkUpdate();


////        if (!getSharedPreferences("MS", MODE_PRIVATE).getBoolean("SAVED", false)) {
//        SaveDataInRoom();
//        /*} else {
            setTimer();
            if (!hasDeepLink()) {
                autoAuthenticate();
            }
//        }
//*/
    }

    private void SaveDataInRoom() {
        try {
            List<MedicinesModel> medicinesModelList = CartDatabaseClient.getInstance(this).getCartDatabase().cartDao().GetMedicines();
            Log.d(TAG, "SaveDataInRoom: " + medicinesModelList.size());
            if (medicinesModelList.size() == 0) {
                Volley.newRequestQueue(this).add(new StringRequest(Request.Method.GET, MAIN_URL + "meds.php", response -> {
                    Log.d(TAG, "SaveDataInRoom: " + response);
                    AddMedicine addMedicine = new AddMedicine();
                    addMedicine.execute(response);
                }, error -> {
                    error.printStackTrace();
                    Toast.makeText(SplashActivity.this, "Loading data failed. Please check your internet connection.", Toast.LENGTH_SHORT).show();
                }));
            } else {
                setTimer();
                if (!hasDeepLink()) {
                    autoAuthenticate();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            Volley.newRequestQueue(this).add(new StringRequest(Request.Method.GET, MAIN_URL + "meds.php", response -> {
                Log.d(TAG, "SaveDataInRoom: " + response);
                AddMedicine addMedicine = new AddMedicine();
                addMedicine.execute(response);
            }, error -> {
                error.printStackTrace();
                Toast.makeText(SplashActivity.this, "Loading data failed. Please check your internet connection.", Toast.LENGTH_SHORT).show();
            }));
        }

    }

    private void checkUpdate() {
        Task<AppUpdateInfo> appUpdateInfoTask = appUpdateManager.getAppUpdateInfo();

        appUpdateInfoTask.addOnSuccessListener(appUpdateInfo -> {
            if (appUpdateInfo.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE
                    && appUpdateInfo.isUpdateTypeAllowed(AppUpdateType.IMMEDIATE)) {
                startUpdateFlow(appUpdateInfo);
            } else if (appUpdateInfo.updateAvailability() == UpdateAvailability.DEVELOPER_TRIGGERED_UPDATE_IN_PROGRESS) {
                startUpdateFlow(appUpdateInfo);
            }
        });
    }

    private void startUpdateFlow(AppUpdateInfo appUpdateInfo) {
        try {
            appUpdateManager.startUpdateFlowForResult(appUpdateInfo, AppUpdateType.IMMEDIATE, this, IMMEDIATE_APP_UPDATE_REQ_CODE);
        } catch (IntentSender.SendIntentException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == IMMEDIATE_APP_UPDATE_REQ_CODE) {
            if (resultCode == RESULT_CANCELED) {
                Toast.makeText(getApplicationContext(), "Update canceled", Toast.LENGTH_LONG).show();
            } else if (resultCode == RESULT_OK) {
                Toast.makeText(getApplicationContext(), "Update success!", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(getApplicationContext(), "Update Failed!", Toast.LENGTH_LONG).show();
                checkUpdate();
            }
        }
    }

    private boolean hasDeepLink() {
        boolean result = false;
        Intent intent = getIntent();
        if (intent != null) {
            Uri data = intent.getData();
            if (data != null) {
                String scheme = data.getScheme();
                if (scheme != null && scheme.equals("sendbird")) {
                    Log.i(BaseApplication.TAG, "[SplashActivity] deep link: " + data.toString());
                    mEncodedAuthInfo = data.getHost();
                    if (!TextUtils.isEmpty(mEncodedAuthInfo)) {
                        result = true;
                    }
                }
            }
        }
        return result;
    }

    private void setTimer() {
        mTimer = new Timer();
        mTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                runOnUiThread(() -> {
                    mTimer = null;

                    if (!TextUtils.isEmpty(mEncodedAuthInfo)) {
                        AuthenticationUtils.authenticateWithEncodedAuthInfo(SplashActivity.this, mEncodedAuthInfo, (isSuccess, hasInvalidValue) -> {
                            if (isSuccess) {
                                ActivityUtils.startHomeActivityAndFinish(SplashActivity.this);
                            } else {
                                if (hasInvalidValue) {
                                    ToastUtils.showToast(SplashActivity.this, getString(R.string.calls_invalid_deep_link));
                                } else {
                                    ToastUtils.showToast(SplashActivity.this, getString(R.string.calls_deep_linking_to_authenticate_failed));
                                }
                                finish();
                            }
                        });
                        return;
                    }

                    if (mAutoAuthenticateResult != null) {
                        if (mAutoAuthenticateResult) {
                            ActivityUtils.startHomeActivityAndFinish(SplashActivity.this);
                        } else {
                            ActivityUtils.startLoginActivityAndFinish(SplashActivity.this);
                        }
                    }
                });
            }
        }, SPLASH_TIME_MS);
    }

    private void autoAuthenticate() {
        AuthenticationUtils.autoAuthenticate(mContext, userId -> {
            if (mTimer != null) {
                mAutoAuthenticateResult = !TextUtils.isEmpty(userId);
            } else {
                if (userId != null) {
                    ActivityUtils.startHomeActivityAndFinish(SplashActivity.this);
                } else {
                    ActivityUtils.startLoginActivityAndFinish(SplashActivity.this);
                }
            }
        });
    }

    @Override
    public void onBackPressed() {
        if (mTimer != null) {
            mTimer.cancel();
            mTimer = null;
        }
        super.onBackPressed();
    }

    @SuppressLint("StaticFieldLeak")
    class AddMedicine extends AsyncTask<String, Integer, Void> {

        @Override
        protected Void doInBackground(String... strings) {
            String s = strings[0];

            try {
                JSONArray jsonArray = new JSONArray(s);

                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject object = jsonArray.getJSONObject(i);

                    MedicinesModel medicinesModel = new MedicinesModel();
                    medicinesModel.setDrugDirectoryId(object.getString("drug_directory_id"));
                    medicinesModel.setBrandName(object.getString("brand_name"));
                    medicinesModel.setDosageForm(object.getString("dosage_form"));
                    medicinesModel.setCompany(object.getString("company"));
                    medicinesModel.setStrength(object.getString("strength"));
                    String price = object.getString("price").replaceAll("\\?", "৳").replaceAll("\\(", "\n");
                    StringBuilder stringBuilder = new StringBuilder(price);
                    stringBuilder.deleteCharAt(stringBuilder.length() - 1);
                    medicinesModel.setPrice(stringBuilder.toString());
                    medicinesModel.setGenericName(object.getString("generic_name"));
                    try {
                        CartDatabaseClient.getInstance(SplashActivity.this).getCartDatabase().cartDao().setMedicinesModel(medicinesModel);
                        publishProgress(jsonArray.length(), i);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }


            return null;
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
//            super.onProgressUpdate(values);
            int pr = values[1];
            int total = values[0];
            binding.progressBar.setMax(total);
            binding.progressBar.setProgress(pr);
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            Toast.makeText(SplashActivity.this, "Address Added", Toast.LENGTH_SHORT).show();
            setTimer();
            if (!hasDeepLink()) {
                autoAuthenticate();
            }
            super.onPostExecute(aVoid);
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }
    }
}
