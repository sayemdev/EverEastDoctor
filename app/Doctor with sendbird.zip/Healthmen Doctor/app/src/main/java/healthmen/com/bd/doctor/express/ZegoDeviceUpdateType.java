package healthmen.com.bd.doctor.express;

public enum ZegoDeviceUpdateType {
    cameraOpen,
    cameraClose,
    micUnmute,
    micMute;
}
