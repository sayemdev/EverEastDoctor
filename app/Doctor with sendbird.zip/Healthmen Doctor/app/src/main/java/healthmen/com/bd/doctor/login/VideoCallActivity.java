package healthmen.com.bd.doctor.login;

import static healthmen.com.bd.doctor.Constants.USER_DATA_PREF;
import static healthmen.com.bd.doctor.Constants.USER_ID;
import static healthmen.com.bd.doctor.Constants.USER_NAME;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.TextureView;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.permissionx.guolindev.PermissionX;

import java.util.ArrayList;

import healthmen.com.bd.doctor.R;
import healthmen.com.bd.doctor.databinding.ActivityTestVideoCallBinding;
import healthmen.com.bd.doctor.express.AppCenter;
import healthmen.com.bd.doctor.express.ExpressManager;
import healthmen.com.bd.doctor.express.FloatingWindowService;
import healthmen.com.bd.doctor.express.ZegoDeviceUpdateType;
import healthmen.com.bd.doctor.express.ZegoMediaOptions;
import im.zego.zegoexpress.constants.ZegoUpdateType;
import im.zego.zegoexpress.constants.ZegoViewMode;
import im.zego.zegoexpress.entity.ZegoCanvas;
import im.zego.zegoexpress.entity.ZegoUser;

public class VideoCallActivity extends AppCompatActivity {

    private static final String TAG = "VideoCallActivity";
    ActivityTestVideoCallBinding binding;
    boolean isOpenAble = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityTestVideoCallBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        binding.remoteTexture.setVisibility(View.VISIBLE);
        ExpressManager.getInstance().setLocalVideoView(binding.remoteTexture);

        ExpressManager.getInstance().setExpressHandler(new ExpressManager.ExpressManagerHandler() {
            @Override
            public void onRoomUserUpdate(String roomID, ZegoUpdateType updateType, ArrayList<ZegoUser> userList) {
                Log.d(TAG, "onRoomUserUpdate: " + updateType + " roomId " + roomID + " User List " + userList);
                if (updateType == ZegoUpdateType.ADD) {
                    for (int i = 0; i < userList.size(); i++) {
                        ZegoUser user = userList.get(i);
                        TextureView remoteTexture = binding.remoteTexture;
                        binding.remoteName.setText(user.userName);
                        setRemoteViewVisible(true);
                        ExpressManager.getInstance().setRemoteVideoView(user.userID, remoteTexture);
                        ExpressManager.getInstance().setLocalVideoView(binding.localTexture);
                        isOpenAble = true;
                    }
                } else if (updateType == ZegoUpdateType.DELETE) {
                    for (int i = 0; i < userList.size(); i++) {
                        ZegoUser user = userList.get(i);
                        TextureView remoteTexture = binding.remoteTexture;
                        binding.remoteName.setText(user.userName);
                        setRemoteViewVisible(true);
                        ExpressManager.getInstance().setRemoteVideoView(user.userID, remoteTexture);
                        ExpressManager.getInstance().setLocalVideoView(binding.localTexture);
                    }
                    LeaveRoom();
                } else {
                    setRemoteViewVisible(false);
                }
            }

            @Override
            public void onRoomUserDeviceUpdate(ZegoDeviceUpdateType updateType, String userID, String roomID) {
                Log.d(TAG,
                        "onRoomUserDeviceUpdate() called with: updateType = [" + updateType + "], userID = [" + userID
                                + "], roomID = [" + roomID + "]");
                if (updateType == ZegoDeviceUpdateType.cameraOpen) {
                    setRemoteViewVisible(true);
                } else if (updateType == ZegoDeviceUpdateType.cameraClose) {
                    setRemoteViewVisible(false);
                }
            }

            @Override
            public void onRoomTokenWillExpire(String roomID, int remainTimeInSecond) {

            }
        });


        binding.switchBtn.setSelected(true);
        binding.switchBtn.setOnClickListener(v -> {
            boolean selected = v.isSelected();
            if (selected) {
                v.setSelected(false);
                ExpressManager.getInstance().switchFrontCamera(false);
            } else {
                v.setSelected(true);
                ExpressManager.getInstance().switchFrontCamera(true);
            }
        });

        binding.cameraBtn.setSelected(true);
        binding.cameraBtn.setOnClickListener(v -> {
            boolean selected = v.isSelected();
            if (selected) {
                v.setSelected(false);
                ExpressManager.getInstance().enableCamera(false);
                binding.cameraBtn.setBackgroundResource(R.drawable.circle_white);
            } else {
                v.setSelected(true);
                ExpressManager.getInstance().enableCamera(true);
                binding.cameraBtn.setBackgroundResource(R.drawable.circle_darker);
            }

        });
        binding.micBtn.setSelected(true);
        binding.micBtn.setOnClickListener(v -> {
            boolean selected = v.isSelected();
            if (selected) {
                v.setSelected(false);
                ExpressManager.getInstance().enableMic(false);
                binding.micBtn.setBackgroundResource(R.drawable.circle_white);
            } else {
                v.setSelected(true);
                ExpressManager.getInstance().enableMic(true);
                binding.micBtn.setBackgroundResource(R.drawable.circle_darker);
            }
        });
        binding.logoutRoom.setOnClickListener(v -> {
            LeaveRoom();
        });
//        }

        PermissionX.init(this)
                .permissions(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
                .request((allGranted, grantedList, deniedList) -> {
                });
    }

    private void LeaveRoom() {
        isOpenAble = false;
        ExpressManager.getInstance().leaveRoom();
        getSharedPreferences("CALL", MODE_PRIVATE).edit().clear().apply();
        finish();
        stopService();
    }

    void startService() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, 0);
            } else {
                startService(new Intent(VideoCallActivity.this,
                        FloatingWindowService.class));
            }
        }else{
            startService(new Intent(VideoCallActivity.this,
                    FloatingWindowService.class));
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        stopService();
        if (isOpenAble)
            startService();
    }

    @Override
    protected void onResume() {
        super.onResume();
        stopService(new Intent(this, FloatingWindowService.class));
        binding.remoteTexture.setOpaque(false);
        binding.localTexture.setOpaque(false);
        if (!getSharedPreferences("CALL", MODE_PRIVATE).getBoolean("roomStarted", false)) {
            joinRoom();
        } else {
            ExpressManager.getInstance().setRemoteVideoView(getSharedPreferences("CALL", MODE_PRIVATE).getString("participant", ""), binding.remoteTexture);
        }
    }

    private void joinRoom() {
        String userID = getSharedPreferences(USER_DATA_PREF, MODE_PRIVATE).getString(USER_ID, "");
        String userName = getSharedPreferences(USER_DATA_PREF, MODE_PRIVATE).getString(USER_NAME, "");
        ZegoUser user = new ZegoUser(userID, userName);
        String token = ExpressManager.generateToken(userID, AppCenter.appID, AppCenter.serverSecret);
        int mediaOptions = ZegoMediaOptions.autoPlayAudio | ZegoMediaOptions.autoPlayVideo |
                ZegoMediaOptions.publishLocalAudio | ZegoMediaOptions.publishLocalVideo;
        ExpressManager.getInstance().joinRoom(getIntent().getStringExtra("roomId"), user, token, mediaOptions, (errorCode, jsonObject) -> {
            if (errorCode == 0) {
                Log.d(TAG, "joinRoom: Started");
                SharedPreferences.Editor editor = getSharedPreferences("CALL", MODE_PRIVATE).edit();
                editor.putBoolean("roomStarted", true);
                editor.putString("participant", getIntent().getStringExtra("participant"));
                editor.putString("myId", userID);
                editor.putBoolean("isVideo", true);
                editor.putString("name", getIntent().getStringExtra("name"));
                editor.putString("roomId", getIntent().getStringExtra("roomId"));
                editor.apply();
            } else {
                Toast.makeText(getApplication(), "join room failed,errorCode :" + errorCode, Toast.LENGTH_LONG).show();
                Log.d(TAG, "joinRoom: join room failed,errorCode :" + errorCode + " json " + jsonObject);
            }
        });
    }


    private void setRemoteViewVisible(boolean visible) {
        binding.remoteTexture.setVisibility(View.VISIBLE);
    }

    public void stopService() {
        stopService(new Intent(this, FloatingWindowService.class));
    }

}