package healthmen.com.bd.doctor.Activity;

import android.content.Intent;
import android.graphics.Paint;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.hbb20.CountryCodePicker;

import java.util.Objects;

import healthmen.com.bd.doctor.R;
import healthmen.com.bd.doctor.Utils;

import static healthmen.com.bd.doctor.Utils.redirectToVerification;

public class LoginActivity extends AppCompatActivity {

    TextView dontHaveAnAccount, forgotPasswordTextView;
    EditText doctorIdEt, passwordEditText;
    String from;
    ImageView back;
    String phone,doctorId;
    private String countryCode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        from = getIntent().getStringExtra("from");
        phone = getIntent().getStringExtra("phone");

        dontHaveAnAccount = findViewById(R.id.notHaveAccount);
        forgotPasswordTextView = findViewById(R.id.forgotPassword);
        doctorIdEt = findViewById(R.id.doctorIdEt);
        passwordEditText = findViewById(R.id.passwordEt);
        dontHaveAnAccount.setPaintFlags(dontHaveAnAccount.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
        dontHaveAnAccount.setOnClickListener(v -> redirectToVerification(LoginActivity.this, "Apply"));
        /* forgotPasswordTextView.setOnClickListener(v -> redirectToActivity(healthmen.com.bd.healthmen.Activity.LoginActivity.this, ForgotPasswordActivity.class));
         */

        doctorIdEt.setText(getIntent().getStringExtra("id"));

        back = findViewById(R.id.back);
        back.setOnClickListener(v -> finish());
        if (Objects.equals(null, from)) {
            back.setVisibility(View.INVISIBLE);
        }

    }

    @Override
    public void onBackPressed() {
        if (!Objects.equals(null, from)) {
            super.onBackPressed();
        } else {
            Intent a = new Intent(Intent.ACTION_MAIN);
            a.addCategory(Intent.CATEGORY_HOME);
            a.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(a);
        }
    }

    public void Login(View view) {
        if (!TextUtils.isEmpty(doctorIdEt.getText().toString().trim()) && !TextUtils.isEmpty(passwordEditText.getText().toString().trim())) {
            Utils.Login(doctorIdEt.getText().toString().trim(), passwordEditText.getText().toString().trim(),phone,LoginActivity.this);
        }
    }
}