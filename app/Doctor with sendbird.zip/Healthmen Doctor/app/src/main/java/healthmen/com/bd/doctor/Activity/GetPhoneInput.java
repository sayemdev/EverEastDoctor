package healthmen.com.bd.doctor.Activity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Paint;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.chaos.view.PinView;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;
import com.hbb20.CountryCodePicker;

import java.util.Locale;
import java.util.concurrent.TimeUnit;

import healthmen.com.bd.doctor.DialogFragment.EditNumberFragment;
import healthmen.com.bd.doctor.R;

public class GetPhoneInput extends AppCompatActivity implements EditNumberFragment.EditPhoneNumberValueListener {

    private static final String TAG = "GetPhoneInput";
    TextView getOtp, userPhoneTextView, editNumber, timerTextView;
    EditText phoneEditText;
    CountryCodePicker countryCodePicker;
    String countryCode, phone, phoneFromIntent;
    PinView pinView;
    StringBuilder stringBuilder;
    String phoneNormal, to;
    ImageView back;
    Button button;
    String phoneFinal;
    private StringBuilder stringBuilder1;
    private FirebaseAuth firebaseAuth;
    private String vId;
    private LinearLayout confirmOtpLayout, sendOtpLayout;
    private String otp;
    private CountDownTimer countDownTimer;
    private final PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallBack = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {

        @Override
        public void onCodeSent(@NonNull String s, @NonNull PhoneAuthProvider.ForceResendingToken forceResendingToken) {
            super.onCodeSent(s, forceResendingToken);
            Toast.makeText(getApplicationContext(), "Verification Code sent", Toast.LENGTH_SHORT).show();
            vId = s;
            button.setEnabled(true);
        }

        @Override
        public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {
            String code = phoneAuthCredential.getSmsCode();
            if (code != null) {
                pinView.setText(code);
                verifyCode(code);
                button.setEnabled(true);
            }

        }

        @Override
        public void onVerificationFailed(@NonNull FirebaseException e) {
            Toast.makeText(getApplicationContext(), "Something went wrong...Please try again" + e.getMessage(), Toast.LENGTH_SHORT).show();
            e.printStackTrace();
            getOtp.setText(R.string.resend_otp);
            sendOtpLayout.setVisibility(View.VISIBLE);
            countDownTimer.cancel();
            confirmOtpLayout.setVisibility(View.GONE);
            button.setEnabled(false);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_phone_input);

        firebaseAuth = FirebaseAuth.getInstance();

        phoneFromIntent = getIntent().getStringExtra("phone");
        to = getIntent().getStringExtra("to");


        back = findViewById(R.id.back);
        timerTextView = findViewById(R.id.timer);
        editNumber = findViewById(R.id.editNumber);
        getOtp = findViewById(R.id.getOtp);
        phoneEditText = findViewById(R.id.phone);
        countryCodePicker = findViewById(R.id.ccp);
        pinView = findViewById(R.id.pinView);
        sendOtpLayout = findViewById(R.id.getOtpLayout);
        confirmOtpLayout = findViewById(R.id.otpLayout);
        userPhoneTextView = findViewById(R.id.userPhone);
        button = findViewById(R.id.verifyButton);

        if (phoneFromIntent != null) {
            phoneEditText.setText(phoneFromIntent);
        }
        back.setOnClickListener(v -> finish());

        timerTextView.setPaintFlags(timerTextView.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
        editNumber.setPaintFlags(editNumber.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);

        countDownTimer = new CountDownTimer(60000, 1000) {
            @SuppressLint("SetTextI18n")
            @Override
            public void onTick(long millisUntilFinished) {
                int minutes = (int) (millisUntilFinished / 1000) / 60;
                int seconds = (int) (millisUntilFinished / 1000) % 60;
                String time = String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds);
                timerTextView.setText("Resend OTP in " + time);
            }

            @Override
            public void onFinish() {
                Toast.makeText(GetPhoneInput.this, "Connection timeout...\n Resend OTP", Toast.LENGTH_SHORT).show();
                getOtp.setText(R.string.resend_otp);
                sendOtpLayout.setVisibility(View.VISIBLE);
                confirmOtpLayout.setVisibility(View.GONE);
            }
        };

        getOtp.setOnClickListener(v -> {
            stringBuilder = new StringBuilder();
            phone = phoneEditText.getText().toString();
            if (TextUtils.isEmpty(phone)) {
                phoneEditText.setError("Enter a phone number");
                phoneEditText.requestFocus();
            } else if (!TextUtils.isEmpty(phone)) {
                stringBuilder.append(phone);
                countryCode = countryCodePicker.getTextView_selectedCountry().getText().toString();
                stringBuilder1 = new StringBuilder(countryCode);
                if (String.valueOf(stringBuilder.charAt(0)).equals("0")) {
                    stringBuilder.deleteCharAt(0);
                }
                if (stringBuilder.length() != 10) {
                    phoneEditText.setError("Enter a valid phone number");
                    phoneEditText.requestFocus();
                } else {
                    phoneNormal = "0" + stringBuilder;
                    stringBuilder1.append(stringBuilder);
                    sendOtp(stringBuilder1.toString());
                    userPhoneTextView.setText(stringBuilder1);
                    confirmOtpLayout.setVisibility(View.VISIBLE);
                    countDownTimer.start();
                    sendOtpLayout.setVisibility(View.GONE);

                }
            }
        });
        editNumber.setOnClickListener(v -> {
            EditNumberFragment editNumberFragment = new EditNumberFragment("0" + stringBuilder.toString());
            editNumberFragment.show(getSupportFragmentManager(), editNumberFragment.getTag());
            countDownTimer.cancel();
        });
    }

    private void sendOtp(String phone) {
        phoneFinal = phone;
        PhoneAuthOptions options =
                PhoneAuthOptions.newBuilder(firebaseAuth)
                        .setPhoneNumber(phone)       // Phone number to verify
                        .setTimeout(60L, TimeUnit.SECONDS) // Timeout and unit
                        .setActivity(this)                 // Activity (for callback binding)
                        .setCallbacks(mCallBack)          // OnVerificationStateChangedCallbacks
                        .build();
        /*PhoneAuthProvider.getInstance().verifyPhoneNumber(phone,
                60,
                TimeUnit.SECONDS,
                TaskExecutors.MAIN_THREAD,
                mCallBack);*/
        PhoneAuthProvider.verifyPhoneNumber(options);

    }

    private void verifyCode(String pin) {
        try {
            PhoneAuthCredential credential = PhoneAuthProvider.getCredential(vId, pin);
            verifyWithCredential(credential);
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void verifyWithCredential(PhoneAuthCredential credential) {
        firebaseAuth.signInWithCredential(credential).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                Toast.makeText(getApplicationContext(), "Verification done...", Toast.LENGTH_SHORT).show();
                countDownTimer.cancel();
                Intent intent2 = new Intent(GetPhoneInput.this, ApplyToWorkActivity.class);
                intent2.putExtra("phone", phoneNormal);

                Intent intent = new Intent(GetPhoneInput.this, LoginActivity.class);
                intent.putExtra("phone", phoneFinal);
                intent.putExtra("from", "non-null");

                try {
                    if (to.equals("Apply")) {
                        startActivity(intent2);
                        finish();
                    } else if (to.equals("Login")) {
                        startActivity(intent);
                        finish();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }

                /*confirmOtpLayout.setVisibility(View.GONE);
                sendOtpLayout.setVisibility(View.GONE);*/
            } else {
                Toast.makeText(getApplicationContext(), "Your otp doesn't matched or something went wrong.Please try again.", Toast.LENGTH_SHORT).show();
                task.getException().printStackTrace();
                Log.e(TAG, "verifyWithCredential: ", task.getException());
                getOtp.setText(R.string.resend_otp);
                sendOtpLayout.setVisibility(View.VISIBLE);
                countDownTimer.cancel();
                confirmOtpLayout.setVisibility(View.GONE);
                button.setEnabled(false);
                pinView.setText("");
            }
        });
    }

    public void Verify(View view) {
        try {
            otp = pinView.getText().toString().trim();
        } catch (Exception e) {
            e.printStackTrace();
            Log.i("ADREG2", "ConfirmOTP: " + e.getMessage());
        }
        if (!TextUtils.isEmpty(otp)) {
            verifyCode(otp);
        }
    }

    public void EditNumber(View view) {

    }

    @Override
    public void ApplyPhoneValue(String phone) {
        Intent intent = new Intent(this, GetPhoneInput.class);
        intent.putExtra("phone", phone);
        startActivity(intent);
        finish();
    }

    @Override
    protected void onDestroy() {
        countDownTimer.cancel();
        super.onDestroy();
    }
}