package healthmen.com.bd.doctor.utils;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;

import androidx.annotation.NonNull;

import com.sendbird.calls.DirectCall;

import healthmen.com.bd.doctor.Activity.HomeActivity;
import healthmen.com.bd.doctor.Activity.LoginActivity;
import healthmen.com.bd.doctor.Activity.MainActivity;
import healthmen.com.bd.doctor.Activity.PendingMessageActivity;
import healthmen.com.bd.doctor.Constants;
import healthmen.com.bd.doctor.call.VideoCallActivity;
import healthmen.com.bd.doctor.call.VoiceCallActivity;
import healthmen.com.bd.doctor.main.ApplicationInformationActivity;
import healthmen.com.bd.doctor.main.SignInManuallyActivity;

import static healthmen.com.bd.doctor.Constants.HAS_OPEN;

public class ActivityUtils {

    public static final int START_SIGN_IN_MANUALLY_ACTIVITY_REQUEST_CODE = 1;
    private static final String TAG = "ActivityUtils";

    @SuppressLint("LongLogTag")
    public static void startLoginActivityAndFinish(@NonNull Activity activity) {
        Log.i(BaseApplication.TAG, "[ActivityUtils] startAuthenticateActivityAndFinish()");

        SharedPreferences sharedPreferences = activity.getSharedPreferences(Constants.USER_DATA_PREF, Context.MODE_PRIVATE);
        boolean hasOpen = sharedPreferences.getBoolean(HAS_OPEN, false);
        if (hasOpen) {
            Intent intent = new Intent(activity, LoginActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            activity.startActivity(intent);
        } else {
            Intent intent = new Intent(activity, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
            activity.startActivity(intent);
        }
        activity.finish();
    }

    @SuppressLint("LongLogTag")
    public static void startWaitingActivityAndFinish(@NonNull Activity activity) {
        Log.i(BaseApplication.TAG, "[ActivityUtils] startAuthenticateActivityAndFinish()");
        Intent intent = new Intent(activity, PendingMessageActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        activity.startActivity(intent);
        activity.finish();
    }

    @SuppressLint("LongLogTag")
    public static void startSignInManuallyActivityForResult(@NonNull Activity activity) {
        Log.i(BaseApplication.TAG, "[ActivityUtils] startSignInManuallyActivityAndFinish()");
        Intent intent = new Intent(activity, SignInManuallyActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        activity.startActivityForResult(intent, START_SIGN_IN_MANUALLY_ACTIVITY_REQUEST_CODE);
    }

    @SuppressLint("LongLogTag")
    public static void startHomeActivityAndFinish(@NonNull Activity activity) {
        Log.i(BaseApplication.TAG, "[ActivityUtils] startMainActivityAndFinish()");

        Intent intent = new Intent(activity, HomeActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        activity.startActivity(intent);
        activity.finish();
    }

    @SuppressLint("LongLogTag")
    public static void startApplicationInformationActivity(@NonNull Activity activity) {
        Log.i(BaseApplication.TAG, "[ActivityUtils] startApplicationInformationActivity()");

        Intent intent = new Intent(activity, ApplicationInformationActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        activity.startActivity(intent);
    }

    public static void startCallActivityAsCallee(Context context, DirectCall call) {
        Log.d(TAG, "startCallActivityAsCallee()");
        final Intent intent;
        if (call.isVideoCall()) {
            intent = new Intent(context, VideoCallActivity.class);
        } else {
            intent = new Intent(context, VoiceCallActivity.class);
        }
        intent.putExtra("EXTRA_INCOMING_CALL_ID", call.getCallId());
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
        context.startActivity(intent);
    }
}