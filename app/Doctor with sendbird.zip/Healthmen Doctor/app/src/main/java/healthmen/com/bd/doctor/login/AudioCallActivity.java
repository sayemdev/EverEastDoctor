package healthmen.com.bd.doctor.login;

import static healthmen.com.bd.doctor.Constants.USER_DATA_PREF;
import static healthmen.com.bd.doctor.Constants.USER_ID;
import static healthmen.com.bd.doctor.Constants.USER_NAME;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.util.Log;
import android.view.TextureView;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.permissionx.guolindev.PermissionX;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import healthmen.com.bd.doctor.R;
import healthmen.com.bd.doctor.databinding.ActivityTestAudioCallBinding;
import healthmen.com.bd.doctor.express.AppCenter;
import healthmen.com.bd.doctor.express.AudioFloatingWindowService;
import healthmen.com.bd.doctor.express.ExpressManager;
import healthmen.com.bd.doctor.express.ZegoDeviceUpdateType;
import healthmen.com.bd.doctor.express.ZegoMediaOptions;
import im.zego.zegoexpress.constants.ZegoUpdateType;
import im.zego.zegoexpress.constants.ZegoViewMode;
import im.zego.zegoexpress.entity.ZegoCanvas;
import im.zego.zegoexpress.entity.ZegoUser;

public class AudioCallActivity extends AppCompatActivity {

    private static final String TAG = "AudioCallActivity";
    private final Handler handler = new Handler();
    ActivityTestAudioCallBinding binding;
    boolean isOpenAble = false;
    Date callStartedAt;
    private Runnable runnable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityTestAudioCallBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.remoteName.setText(getIntent().getStringExtra("name"));

        ExpressManager.getInstance().setExpressHandler(new ExpressManager.ExpressManagerHandler() {
            @Override
            public void onRoomUserUpdate(String roomID, ZegoUpdateType updateType, ArrayList<ZegoUser> userList) {
                Log.d(TAG, "onRoomUserUpdate: " + updateType + " roomId " + roomID + " User List " + userList);
                if (updateType == ZegoUpdateType.ADD) {
                    for (int i = 0; i < userList.size(); i++) {
                        ZegoUser user = userList.get(i);
                        TextureView remoteTexture = binding.remoteTexture;
                        binding.remoteName.setText(user.userName);
                        setRemoteViewVisible(true);
                        ExpressManager.getInstance().setRemoteVideoView(user.userID, remoteTexture);
                        ExpressManager.getInstance().setLocalVideoView(binding.localTexture);
                        isOpenAble = true;

                        try {
                            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
                            Date date = new Date();
                            String dateTime = format.format(date);
                            getSharedPreferences("CALL", MODE_PRIVATE).edit().putString("STARTED_AT", dateTime).apply();
                            String dtStart = getSharedPreferences("CALL", MODE_PRIVATE).getString("STARTED_AT", dateTime);
                            callStartedAt = format.parse(dtStart);
                            runnable = new Runnable() {
                                @Override
                                public void run() {
                                    try {
                                        handler.postDelayed(this, 1000);
                                        Date current_date = new Date();
                                        long diff = current_date.getTime() - callStartedAt.getTime();
                                        long Minutes = diff / (60 * 1000) % 60;
                                        long Seconds = diff / 1000 % 60;

                                        binding.timeTV.setText(String.format("%02d:%02d", Minutes, Seconds));

                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                }
                            };
                            handler.postDelayed(runnable, 0);
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }

                    }
                } else if (updateType == ZegoUpdateType.DELETE) {
                    for (int i = 0; i < userList.size(); i++) {
                        ZegoUser user = userList.get(i);
                        TextureView remoteTexture = binding.remoteTexture;
                        binding.remoteName.setText(user.userName);
                        setRemoteViewVisible(true);
                        ExpressManager.getInstance().setRemoteVideoView(user.userID, remoteTexture);
                        ExpressManager.getInstance().setLocalVideoView(binding.localTexture);
                    }
                    LeaveRoom();
                } else {
                    setRemoteViewVisible(false);
                }
            }

            @Override
            public void onRoomUserDeviceUpdate(ZegoDeviceUpdateType updateType, String userID, String roomID) {
                Log.d(TAG,
                        "onRoomUserDeviceUpdate() called with: updateType = [" + updateType + "], userID = [" + userID
                                + "], roomID = [" + roomID + "]");
                if (updateType == ZegoDeviceUpdateType.cameraOpen) {
                    setRemoteViewVisible(true);
                } else if (updateType == ZegoDeviceUpdateType.cameraClose) {
                    setRemoteViewVisible(false);
                }
            }

            @Override
            public void onRoomTokenWillExpire(String roomID, int remainTimeInSecond) {

            }
        });


/*        binding.cameraBtn.setSelected(false);
        binding.cameraBtn.setOnClickListener(v -> {
            boolean selected = v.isSelected();
            if (selected) {
                v.setSelected(false);
                ExpressManager.getInstance().enableCamera(false);
                binding.cameraBtn.setBackgroundResource(R.drawable.circle_white);
                getSharedPreferences("CALL", MODE_PRIVATE).edit().putBoolean("isVideo", false).apply();
            } else {
                v.setSelected(true);
                ExpressManager.getInstance().enableCamera(true);
                binding.cameraBtn.setBackgroundResource(R.drawable.circle_darker);
                getSharedPreferences("CALL", MODE_PRIVATE).edit().putBoolean("isVideo", true).apply();
            }
            if (getSharedPreferences("CALL", MODE_PRIVATE).getBoolean("isVideo", false)) {
                binding.remoteTexture.setVisibility(View.VISIBLE);
                binding.localTexture.setVisibility(View.VISIBLE);
                binding.remoteName.setVisibility(View.GONE);
                binding.timeTV.setVisibility(View.GONE);
            } else {
                binding.remoteTexture.setVisibility(View.GONE);
                binding.localTexture.setVisibility(View.GONE);
                binding.remoteName.setVisibility(View.VISIBLE);
                binding.timeTV.setVisibility(View.VISIBLE);
            }
        });*/
        binding.micBtn.setSelected(true);
        binding.micBtn.setOnClickListener(v -> {
            boolean selected = v.isSelected();
            if (selected) {
                v.setSelected(false);
                ExpressManager.getInstance().enableMic(false);
                binding.micBtn.setBackgroundResource(R.drawable.circle_white);
            } else {
                v.setSelected(true);
                ExpressManager.getInstance().enableMic(true);
                binding.micBtn.setBackgroundResource(R.drawable.circle_darker);
            }
        });
        binding.endRoomButton.setOnClickListener(v -> {
            LeaveRoom();
        });
//        }

        PermissionX.init(this)
                .permissions(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
                .request((allGranted, grantedList, deniedList) -> {
                });
    }

    private void LeaveRoom() {
        isOpenAble = false;
        ExpressManager.getInstance().leaveRoom();
        getSharedPreferences("CALL", MODE_PRIVATE).edit().clear().apply();
        finish();
        stopService();
    }

    void startService() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (Settings.canDrawOverlays(this)) {
                startService(new Intent(AudioCallActivity.this,
                        AudioFloatingWindowService.class));
            } else {
                Intent intent1 = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getApplicationContext().getPackageName()));
                startActivityForResult(intent1, 1);
            }
        } else {
            startService(new Intent(AudioCallActivity.this, AudioFloatingWindowService.class));
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        stopService();
        if (getSharedPreferences("CALL", MODE_PRIVATE).getBoolean("roomStarted", false)) {
            startService();
        }
    }

    private ZegoCanvas generateCanvas(TextureView textureView) {
        ZegoCanvas canvas = new ZegoCanvas(textureView);
        canvas.viewMode = ZegoViewMode.ASPECT_FILL;
        return canvas;
    }

    @Override
    protected void onResume() {
        super.onResume();
        stopService(new Intent(this, AudioFloatingWindowService.class));
        binding.remoteTexture.setOpaque(false);
        binding.localTexture.setOpaque(false);
        if (!getSharedPreferences("CALL", MODE_PRIVATE).getBoolean("roomStarted", false)) {
            joinRoom();
        } else {
            /*ZegoCanvas canvas = generateCanvas(binding.remoteTexture);
            ZegoExpressEngine.getEngine().startPlayingStream(ExpressManager.getInstance().generateStreamID(getSharedPreferences("CALL", MODE_PRIVATE).getString("participant", ""),
                    getSharedPreferences("CALL", MODE_PRIVATE).getString("roomId", "")), canvas);
*/
            try {
                SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
                String dtStart = getSharedPreferences("CALL", MODE_PRIVATE).getString("STARTED_AT", "00");
                if (!dtStart.equals("00")) {
                    callStartedAt = format.parse(dtStart);
                    runnable = new Runnable() {
                        @Override
                        public void run() {
                            try {
                                handler.postDelayed(this, 1000);
                                Date current_date = new Date();
                                long diff = current_date.getTime() - callStartedAt.getTime();
                                long Minutes = diff / (60 * 1000) % 60;
                                long Seconds = diff / 1000 % 60;

                                binding.timeTV.setText(String.format("%02d:%02d", Minutes, Seconds));

                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    };
                    handler.postDelayed(runnable, 0);
                }
            } catch (ParseException e) {
                e.printStackTrace();
            }

            if (getSharedPreferences("CALL", MODE_PRIVATE).getBoolean("isVideo", false)) {
                binding.remoteTexture.setVisibility(View.VISIBLE);
                binding.localTexture.setVisibility(View.VISIBLE);
                binding.remoteName.setVisibility(View.GONE);
                binding.timeTV.setVisibility(View.GONE);
                binding.cameraBtn.setBackgroundResource(R.drawable.circle_white);
                binding.cameraBtn.setSelected(true);
                ExpressManager.getInstance().setRemoteVideoView(getSharedPreferences("CALL", MODE_PRIVATE).getString("participant", ""), binding.remoteTexture);
                ExpressManager.getInstance().setLocalVideoView(binding.localTexture);
            } else {
                binding.remoteTexture.setVisibility(View.GONE);
                binding.localTexture.setVisibility(View.GONE);
                binding.remoteName.setVisibility(View.VISIBLE);
                binding.timeTV.setVisibility(View.VISIBLE);
                binding.cameraBtn.setBackgroundResource(R.drawable.circle_darker);
                binding.cameraBtn.setSelected(false);
            }
        }
    }

    private void joinRoom() {
        String userID = getSharedPreferences(USER_DATA_PREF, MODE_PRIVATE).getString(USER_ID, "");
        String userName = getSharedPreferences(USER_DATA_PREF, MODE_PRIVATE).getString(USER_NAME, "");
        ZegoUser user = new ZegoUser(userID, userName);
        String token = ExpressManager.generateToken(userID, AppCenter.appID, AppCenter.serverSecret);
        int mediaOptions = ZegoMediaOptions.autoPlayAudio |
                ZegoMediaOptions.publishLocalAudio;
        ExpressManager.getInstance().joinRoom(getIntent().getStringExtra("roomId"), user, token, mediaOptions, (errorCode, jsonObject) -> {
            if (errorCode == 0) {
                Log.d(TAG, "joinRoom: Started");
                SharedPreferences.Editor editor = getSharedPreferences("CALL", MODE_PRIVATE).edit();
                editor.putBoolean("roomStarted", true);
                editor.putString("participant", getIntent().getStringExtra("participant"));
                editor.putString("myId", userID);
                editor.putString("name", getIntent().getStringExtra("name"));
                editor.putString("roomId", getIntent().getStringExtra("roomId"));
                editor.apply();
                binding.timeTV.setText("Calling");
                ExpressManager.getInstance().enableSpeaker(false);
            } else {
                Toast.makeText(getApplication(), "join room failed,errorCode :" + errorCode, Toast.LENGTH_LONG).show();
                Log.d(TAG, "joinRoom: join room failed,errorCode :" + errorCode + " json " + jsonObject);
            }
        });
    }

    private void setRemoteViewVisible(boolean visible) {
        /*if (visible){
            binding.remoteTexture.setVisibility(View.VISIBLE);
            ExpressManager.getInstance().setRemoteVideoView(getSharedPreferences("CALL",MODE_PRIVATE).getString("participant",""),binding.remoteTexture);
        }else{
            binding.remoteTexture.setVisibility(View.GONE);
        }*/
    }

    public void stopService() {
        stopService(new Intent(this, AudioFloatingWindowService.class));
    }


}